export const environment = {
  production: false,
  baseUrl : 'http://192.168.2.4/flexhealth/public/index.php/',
  apiUrl:'http://192.168.2.4/flexhealth/public/index.php/api/',
  downUrl : 'https://operations-flexhealth-me.s3.us-east-1.amazonaws.com//',
  googleAPI:'AIzaSyAzEuG-vy7Ni3cBGsBN4N2HR2ZigkmZDck',
  AllowedHosts: "*",
  TwilioAccountSid:"AccountSID",
  TwilioApiSecret:"API Secret",
  TwilioApiKey:"SID"
};