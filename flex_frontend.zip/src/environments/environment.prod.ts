export const environment = {
  production: true,
  baseUrl:'https://flexhealth.me/',
  apiUrl:'https://flexhealth.me/api/',
  downUrl : 'https://operations-flexhealth-me.s3.us-east-1.amazonaws.com/',
  googleAPI:'AIzaSyAzEuG-vy7Ni3cBGsBN4N2HR2ZigkmZDck',
  AllowedHosts: "*",
  TwilioAccountSid:"AccountSID",
  TwilioApiSecret:"API Secret",
  TwilioApiKey:"SID"
};