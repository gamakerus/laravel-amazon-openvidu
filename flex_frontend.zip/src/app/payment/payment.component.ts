import { Component, OnInit, AfterViewInit, ChangeDetectorRef, ElementRef, OnDestroy, Input, Output, EventEmitter } from '@angular/core';
import { ApiService } from '../services/api.service';
declare var Stripe: any;
declare var elements: any;
declare var $: any;
@Component({
	selector: 'app-payment',
	templateUrl: './payment.component.html',
	styleUrls: ['./payment.component.scss']
})
export class PaymentComponent implements OnInit {
	public stripeVal;
	public element;
	public card;
	public scriptDom;
	@Input() totalPrice:any
	@Input() payTarget:any
	@Input() jobId:any
	@Output() processAfterPay = new EventEmitter<any>();
	loading = false;
	constructor(
		private cd: ChangeDetectorRef,
		private apiservice: ApiService,
	) { }
	loadStripe() {
		 
		if(!window.document.getElementById('stripe-custom-form-script')) {
			// this.apiservice.getStripeKey().subscribe((res : any)=>{
				var s = window.document.createElement("script");
				s.id = "stripe-custom-form-script";
				s.type = "text/javascript";
				s.src = "https://js.stripe.com/v3/";
				s.onload = () => {
					this.stripeVal = Stripe('pk_test_DnMPKiTTDo4zYGv062gzjHOP00CaifSI4u');
					this.element = this.stripeVal.elements();
					let config = {
						iconStyle: 'solid',
						style: {
							base: {
								lineHeight: '32px',
								fontWeight: 300,
								fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
								fontSize: '16px',
								fontSmoothing: 'antialiased',
								color:(this.payTarget=='signup'?'#333':'#fff'),
								iconColor: (this.payTarget=='signup'?'#0cf':'#fff'),
								'::placeholder': {
									color: '#0cf',
								},
							},
							invalid: {
								iconColor: '#e85746',
								color: '#e85746',
							}
						},
						classes: {
							focus: 'is-focused',
							empty: 'is-empty',
						},
						value:"{currency: 'usd'}"
					}
					this.card = this.element.create('card',config);
					this.card.mount('#card-element');
					this.card.addEventListener('change', function(event) {
						var displayError = document.getElementById('card-errors');
						if (event.error) {
							displayError.textContent = event.error.message;
						} else {
							displayError.textContent = '';
						}
					});
					
				}
				this.scriptDom = s;
				window.document.body.appendChild(s);
			// })
		}
	}
	ngOnInit() {
		this.loadStripe();
	}
	ngOnDestroy(){
		this.scriptDom.remove();
	}
	async createStripeToken() {
		this.loading = true
		const {token, error} = await this.stripeVal.createToken(this.card, {currency:'usd'});
		if (token) {
			this.onSuccess(token);
		} else {
			this.onError(error);
		}
	}
	onSuccess(token) {
		if(this.payTarget=='signup'){
			this.apiservice.requestSignupPay(token.id).subscribe(
				data=>{
					this.loading = false
					if(data.status=='success')
						this.processAfterPay.emit(true)
					else
						this.processAfterPay.emit(false)
				},
				error=>{
					this.loading = false
					this.processAfterPay.emit(false)
				}
			)
		} else if(this.payTarget=='interview'){
			this.apiservice.requestInterviewPay(token.id).subscribe(
				data=>{
					this.loading = false
					if(data.status=='success')
						this.processAfterPay.emit(true)
					else
						this.processAfterPay.emit(false)
				},
				error=>{
					this.loading = false
					this.processAfterPay.emit(false)
				}
			)
		} else {
			this.apiservice.requestPay(token.id, this.jobId).subscribe(
				data=>{
					this.loading = false
					console.log(data)
					this.processAfterPay.emit(true)
				},
				error=>{
					this.loading = false
					this.processAfterPay.emit(false)
				}
			)
		}
		console.log({token});
	}
	onError(error) {
		console.log(error)
		this.processAfterPay.emit(false)
	}
}
