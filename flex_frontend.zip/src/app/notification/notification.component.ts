import { Component, OnInit } from '@angular/core';
import { ApiService } from '../services/api.service';
import { ActivatedRoute } from '@angular/router';
declare var $: any;
@Component({
	selector: 'app-notification',
	templateUrl: './notification.component.html',
	styleUrls: ['./notification.component.scss']
})
export class NotificationComponent implements OnInit {
	notifications = []
	filePath = ''
	page = 1
	maxpage = 1
	constructor(
		private apiservice: ApiService,
		private route: ActivatedRoute,
	) {
		this.filePath = apiservice.env.downUrl
	}

	ngOnInit(): void {
		this.route.params.subscribe(params => {
			if(params['page'])
				this.page = parseInt(params['page']);
			this.apiservice.getNotifications(this.page).subscribe(
				data=>{
					if(data && data.status=="success"){
						this.maxpage = data.totalpage
						this.notifications = data.notification
					}
				}
			)
		});
	}
	accordion(target, index){
		if(this.notifications[index].checked==0){
			this.apiservice.setReadNotification(this.notifications[index].id).subscribe(
				data=>{
					if(data && data.status=="success"){
						this.notifications[index]['checked']=1
					}
				}
			)
		}
		$(target).collapse('toggle');
	}
}
