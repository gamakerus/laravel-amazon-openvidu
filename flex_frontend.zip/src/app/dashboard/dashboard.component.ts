import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from  '@angular/material/dialog';
import { ApiService } from '../services/api.service';
import { environment } from '../../environments/environment';
import { ImageEditerComponent} from "../layout/image-editer/image-editer.component";
import { SearchfilterComponent} from "../client/searchfilter/searchfilter.component";

declare var $: any;

@Component({
	selector: 'app-dashboard',
	templateUrl: './dashboard.component.html',
	styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
	croppedImage: any = '';
	myinfo = null
	bioEditFlag = false
	bio = ''
	center = null
	filePath = ''
	constructor(
		private dialog:MatDialog,
		private apiservice: ApiService
	) {
		this.filePath = apiservice.env.downUrl
	}

	ngOnInit(): void {
		this.myinfo = JSON.parse(localStorage.getItem('currentUser'))
		if(this.myinfo.lat!=0 && this.myinfo.lat!=null){
			this.center= {
				lat: parseFloat(this.myinfo.lat), 
				lng: parseFloat(this.myinfo.long)
			}
		} else {
			navigator.geolocation.getCurrentPosition(position => {
				this.center = {
					lat: position.coords.latitude,
					lng: position.coords.longitude,
				}
			})
		}
		this.bio = this.myinfo.bio
	}
	triggerUpload(){
		$("#cover-upload").click()
	}
	fileChangeEvent(event: any): void {
		let dialogConfig = new MatDialogConfig();
		dialogConfig['data'] = {event:event, croppedImage:this.croppedImage, target:'coverimage'}

		const dialogRef = this.dialog.open(ImageEditerComponent, dialogConfig);
		dialogRef.afterClosed().subscribe(result => {
			if(result){
				this.croppedImage = result;
				this.apiservice.updateCoverImg(this.croppedImage).subscribe(
					data =>{
						if(data.status=='success'){
							this.myinfo.coverimg = data.coverimg
							localStorage.setItem('currentUser', JSON.stringify(this.myinfo))
						}
					},
					error=>{
						console.log(error)
					}
				)
			}
			$("#avatar-upload").val('')
		});
	}
	toggleEdit(){
		if(this.bioEditFlag){
			this.apiservice.updateBio(this.bio).subscribe(
				data => {
					console.log(data)
					this.myinfo.bio = this.bio
					localStorage.setItem('currentUser', JSON.stringify(this.myinfo))
				},
				error=>{
					console.log(error)
				}
			)
		}
		this.bioEditFlag = !this.bioEditFlag
	}
	findCareGiver() {
		const dialogConfig = new MatDialogConfig();
		dialogConfig.autoFocus = true;
		dialogConfig.data = {state:'loggedin_redirect'}
		this.dialog.open(SearchfilterComponent, dialogConfig);
	}
}
