import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { GoogleMapsModule } from '@angular/google-maps';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { HttpClientModule } from "@angular/common/http";
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { NgxIntlTelInputModule } from "ngx-intl-tel-input";
import { StarRatingModule } from 'angular-star-rating';

import { 
  SocialLoginModule, 
  SocialAuthServiceConfig,
  GoogleLoginProvider,
  FacebookLoginProvider,
  // AmazonLoginProvider, 
} from 'angularx-social-login';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ClipboardModule } from 'ngx-clipboard';

import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './layout/header/header.component';
import { MainComponent } from './layout/main/main.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { FooterComponent } from './layout/footer/footer.component';
import { LoginComponent } from './login/login.component';

import { MatDialogModule } from "@angular/material/dialog";
import { MatBottomSheetModule } from "@angular/material/bottom-sheet";
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatRadioModule } from '@angular/material/radio';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';

import { OpenviduSessionModule } from 'openvidu-angular';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ImageCropperModule } from 'ngx-image-cropper';
import { ImageEditerComponent } from './layout/image-editer/image-editer.component';
import { ClientComponent } from './signup/client/client.component';
import { ProviderComponent } from './signup/provider/provider.component';
import { ProfileComponent } from './caregiver/profile/profile.component';
import { TimePanelComponent } from './layout/time-panel/time-panel.component';
import { LoadingComponent } from './layout/loading/loading.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SidebarComponent } from './layout/sidebar/sidebar.component';
import { EditprofileComponent } from './caregiver/editprofile/editprofile.component';
import { IncomingComponent } from './caregiver/incoming/incoming.component';
import { OngoingComponent } from './caregiver/ongoing/ongoing.component';
import { PastComponent } from './caregiver/past/past.component';
import { InterviewsComponent } from './caregiver/interviews/interviews.component';
import { SchedulesComponent } from './caregiver/schedules/schedules.component';
import { ServicesComponent } from './caregiver/services/services.component';
import { TransactionsComponent } from './caregiver/transactions/transactions.component';
import { OverviewComponent } from './client/overview/overview.component';
import { FinishedComponent } from './client/finished/finished.component';
import { RefundsComponent } from './client/refunds/refunds.component';
import { EditprofileclientComponent } from './client/editprofile/editprofile.component';
import { IncomingclientComponent } from './client/incoming/incoming.component';
import { OngoingclientComponent } from './client/ongoing/ongoing.component';
import { InterviewsclientComponent } from './client/interviews/interviews.component';
import { TransactionsclientComponent } from './client/transactions/transactions.component';
import { AvatarComponent } from './layout/avatar/avatar.component';
import { RejectComponent } from './caregiver/reject/reject.component';
import { DetailComponent } from './caregiver/detail/detail.component';
import { SearchfilterComponent } from './client/searchfilter/searchfilter.component';
import { SearchresultComponent } from './client/searchresult/searchresult.component';
import { ContactComponent } from './layout/contact/contact.component';
import { FlexdlgComponent } from './layout/flexdlg/flexdlg.component';
import { ResetPassComponent } from './layout/reset-pass/reset-pass.component';
import { ResetEmailComponent } from './layout/reset-email/reset-email.component';
import { ResetPhoneComponent } from './layout/reset-phone/reset-phone.component';
import { ResetpasswordComponent } from './resetpassword/resetpassword.component';
import { HireComponent } from './client/hire/hire.component';
import { BookingComponent } from './client/booking/booking.component';
import { VideocallComponent } from './layout/videocall/videocall.component';
import { NotificationComponent } from './notification/notification.component';
import { LogoutComponent } from './logout/logout.component';
import { ForbiddenComponent } from './forbidden/forbidden.component';
import { AutocompleteComponent } from './layout/autocomplete/autocomplete.component';
import { PaymentComponent } from './payment/payment.component';
import { JobdetailComponent } from './layout/jobdetail/jobdetail.component';
import { RatingComponent } from './layout/rating/rating.component';
import { PaginationComponent } from './layout/pagination/pagination.component';
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    HeaderComponent,
    MainComponent,
    FooterComponent,
    LoginComponent,
    ImageEditerComponent,
    ClientComponent,
    ProviderComponent,
    ProfileComponent,
    TimePanelComponent,
    LoadingComponent,
    DashboardComponent,
    SidebarComponent,
    EditprofileComponent,
    IncomingComponent,
    OngoingComponent,
    PastComponent,
    InterviewsComponent,
    SchedulesComponent,
    ServicesComponent,
    TransactionsComponent,
    OverviewComponent,
    FinishedComponent,
    RefundsComponent,
    EditprofileclientComponent,
    IncomingclientComponent,
    OngoingclientComponent,
    InterviewsclientComponent,
    TransactionsclientComponent,
    AvatarComponent,
    RejectComponent,
    DetailComponent,
    SearchfilterComponent,
    SearchresultComponent,
    ContactComponent,
    FlexdlgComponent,
    ResetPassComponent,
    ResetEmailComponent,
    ResetPhoneComponent,
    ResetpasswordComponent,
    HireComponent,
    BookingComponent,
    VideocallComponent,
    NotificationComponent,
    LogoutComponent,
    ForbiddenComponent,
    AutocompleteComponent,
    PaymentComponent,
    JobdetailComponent,
    RatingComponent,
    PaginationComponent,
  ],
  imports: [
    BrowserModule,
    ClipboardModule,
    AppRoutingModule,
    FontAwesomeModule,
    GoogleMapsModule,
    FormsModule,
    NgSelectModule,
    ReactiveFormsModule,
    HttpClientModule,
    SocialLoginModule,
    MatDialogModule,
    MatCheckboxModule,
    MatRadioModule,
    MatDatepickerModule,
    MatBottomSheetModule,
    MatSidenavModule,
    MatIconModule,
    BrowserAnimationsModule,
    ImageCropperModule,
    MatNativeDateModule,
    BsDropdownModule.forRoot(),
    TooltipModule.forRoot(),
    NgxIntlTelInputModule,
    StarRatingModule.forRoot(),
    OpenviduSessionModule,
  ],
  providers: [
    {
      provide: 'SocialAuthServiceConfig',
      useValue: {
        autoLogin: false,
        providers: [
          {
            id: GoogleLoginProvider.PROVIDER_ID,
            provider: new GoogleLoginProvider(
              '303420204179-tpo6jddaoltpbkg49ctbco72plek5bt3'
            ),
          },
          {
            id: FacebookLoginProvider.PROVIDER_ID,
            provider: new FacebookLoginProvider('608054406803685'),
          }
        ],
      } as SocialAuthServiceConfig,
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
