export class User {
	id: number;
	email: string;
	password: string;
	token: string;
}
export class RegUser {
	name: string;
	fname: string;
	lname: string;
	email: string;
	password: string;
	terms: boolean;
	dob: string;
	phone: string;
	paymethod: number;
	socialFlag:boolean;
	authToken:string;
}