import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
declare var $: any;
@Component({
  selector: 'app-time-panel',
  templateUrl: './time-panel.component.html',
  styleUrls: ['./time-panel.component.scss']
})
export class TimePanelComponent implements OnInit {
	hours = []
	flag = 0
	@Input() start : Number;
	@Input() end : Number;
	@Input() inline:Boolean;
	@Input() livein:Boolean;
	@Input() method:String;
	@Output() startChange = new EventEmitter<Number>();
	@Output() endChange = new EventEmitter<Number>();
	@Output() liveinChange = new EventEmitter<Boolean>();
	@Output() selectHour = new EventEmitter<any>();
	@Output() onClosed: EventEmitter<any> = new EventEmitter<any>();
  constructor() {
    for(let i=1;i<=24;i++){
			if(i == 12)
				this.hours.push("12 PM")
			else if(i == 24)
				this.hours.push("12 AM")
			else if(i > 11)
				this.hours.push(i-12+" PM")
			else
				this.hours.push(i+" AM")
    }
  }

  ngOnInit(): void {
  }
	setActive($event, index){
		if(this.flag==0){
			this.flag = 1
			$($event.target).parent().find(".timeitem").removeClass('active-start')
			$($event.target).parent().find(".timeitem").removeClass('click-start')
			$($event.target).parent().find(".timeitem").removeClass('active-end')
			$($event.target).parent().find(".timeitem").addClass('init')
			$($event.target).addClass('click-start')
			
			this.start = index
		} else {
			this.flag = 0
			if($($event.target).parent().find(".click-start").hasClass('active-start'))
				$($event.target).addClass('active-end')
			else{
				$($event.target).addClass('active-start')
				$($event.target).removeClass('active-end')
			}
			
			this.end = index
			this.startChange.emit(this.start>this.end?this.end:this.start);
			this.endChange.emit(this.start>this.end?this.start:this.end);
		}
	}
	setActiveSingle($event, index){
		if($($event.target).hasClass('disabled'))
			return false
		$($event.target).parent().find(".timeitem").removeClass('active')
		$($event.target).addClass('active')
		this.selectHour.emit(index);
	}
	pendingAcitve($event, index){
		if(this.flag==0)
			return false

		if(index < this.start){
			$($event.target).parent().find(".timeitem").removeClass('active-start')
			$($event.target).parent().find(".timeitem").removeClass('active-end')
			$($event.target).parent().find(".click-start").addClass('active-end')
			$($event.target).addClass('active-start')
		} else {
			$($event.target).parent().find(".timeitem").removeClass('active-end')
			$($event.target).parent().find(".timeitem").removeClass('active-start')
			$($event.target).parent().find(".click-start").addClass('active-start')
			$($event.target).addClass('active-end')
		}
	}
	closeSelf(){
		this.onClosed.emit();
	}
	changeLiveIn(target){
		$(target).find(".timeitem").removeClass('active-end')
		$(target).find(".timeitem").removeClass('active-start')
		if(this.livein){
			this.start = 0
			this.end = 23
		} else {
			this.start = 0
			this.end = 0
		}
		this.liveinChange.emit(this.livein);
	}
}
