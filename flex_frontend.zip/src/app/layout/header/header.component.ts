import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { LoginComponent} from "../../login/login.component";
import { Location } from "@angular/common";
import { ApiService } from '../../services/api.service';
import { AuthenticationService } from '../../services/authentication.service';
import { Router } from '@angular/router';
declare var $: any;
@Component({
	selector: 'app-header',
	templateUrl: './header.component.html',
	styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
	logged = null
	is_homepage = false
	route = ''
	user = null
	avatar = ''
	showFlag = true
	unread = 0
	filePath=''
	sub = null
	sub1 = null
	sub2 = null
	subs = null
	constructor(
		private dialog:MatDialog,
		private router: Router,
		location: Location,
		private apiservice: ApiService,
		private authenticationService: AuthenticationService,
	) {
		router.events.subscribe(val => {
			if (location.path() != "") {
				this.route = location.path();
			} else {
				this.route = "Home";
			}
		});
		this.filePath = apiservice.env.downUrl
	}
	public currentUser=null;
	scrollToTarget($event){
		$event.preventDefault();
		$("html,body").animate({
			scrollTop: $($event.target.hash).offset().top
		}, 1200);
	}
	ngOnInit(): void {
		if(localStorage.getItem('currentUser')!='undefined'){
			this.user = JSON.parse(localStorage.getItem('currentUser'));
		}
		if(localStorage.getItem('user_token')){
			this.logged = {status:'success'}
		}
		else {
			this.logged = {status:'failed'}
		}
		if(this.user && this.user.avatar && this.user.avatar!=''){
			this.avatar =this.user.avatar
		}
		if(this.apiservice.currentMenu=='home'){
			this.is_homepage = true
		}
		this.sub = this.apiservice.hideMenu.subscribe(
			() =>{
				this.showFlag = false
			}
		)
		this.sub1 = this.apiservice.logoutEvent.subscribe(
			()=>{
				this.logged = null
				this.is_homepage = false
				this.route = ''
				this.user = null
				this.avatar = ''
			}
		)
		this.sub2 = this.apiservice.avatarEvent.subscribe(
			(avatar)=>{
				this.user.avatar = avatar;
				this.avatar = avatar
			}
		)
		if(this.user){
			setInterval(function(){
				this.apiservice.checkNotifications().subscribe(
					data=>{
						if(data.status=='success'){
							this.unread = data.unread
						}
					}
				)
			}.bind(this), 10000)
		}
		this.subs = this.apiservice.loginEvent.subscribe(
			()=>{
				this.loginShow()
			}
		)
	}
	ngOnDestroy(){
		if(this.sub)
			this.sub.unsubscribe();
		if(this.sub1)
			this.sub1.unsubscribe();
		if(this.sub2)
			this.sub2.unsubscribe();
		if(this.subs)
	 		this.subs.unsubscribe();
	}
	loginShow() {
		const dialogConfig = new MatDialogConfig();
		// dialogConfig.autoFocus = true;
		this.dialog.open(LoginComponent, dialogConfig);
	}
	logout(){
		this.authenticationService.logout()
		this.logged = null
		window.location.href = ""
	}
}
