import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { ApiService } from '../../services/api.service';
@Component({
	selector: 'app-reset-email',
	templateUrl: './reset-email.component.html',
	styleUrls: ['./reset-email.component.scss']
})
export class ResetEmailComponent implements OnInit {
	confirmEmailFlag = 0
	resendEmailFlag = 0
	email = ''
	codeE = 0
	eCode = ''
	sentFlag = false
	emailErr = 0
	codeErr = 0
	loading = false
	@Output() changedEmail = new EventEmitter<any>();
	constructor(
		private apiservice: ApiService,
	) { }

	ngOnInit(): void {
	}
	confirmEmail(){
		this.codeE = 0
		this.emailErr = 0
		if(this.email==''){
			this.codeE = 1
			this.emailErr = 1
			return false
		} else if(!this.apiservice.validateEmail(this.email)){
			this.codeE = 2
			this.emailErr = 1
			return false
		}
		this.confirmEmailFlag = 1
		this.apiservice.updateEmail(this.email).subscribe(
			data => {
				if(data.status=='success'){
					this.confirmEmailFlag = 2
					this.sentFlag = true
				}else if(data.status=='existed'){
					this.confirmEmailFlag = 3
					this.codeE = 5
				} else {
					this.confirmEmailFlag = 3
					this.codeE = 6
				}
			},
			error => {
				this.confirmEmailFlag = 3
				this.codeE = 6
				console.log(error)
			}
		)
		
	}
	resendEmailCode(){
		this.codeE = 0
		this.resendEmailFlag = 1
		this.apiservice.resendCode().subscribe(
			data => {
				if(data.status=='success'){
					this.resendEmailFlag = 2
					this.sentFlag = true
				} else {
					this.resendEmailFlag = 3
					this.codeE = 6
				}
			},
			error => {
				this.resendEmailFlag = 3
				this.codeE = 6
				console.log(error)
			}
		)
	}
	changeEmail(){
		this.codeE = 0
		this.codeErr = 0
		if(this.eCode==''){
			this.codeE = 3
			return false
		}
		this.loading = true
		
		this.apiservice.confirmEmail(this.eCode).subscribe(
			data => {
				this.loading = false
				if(data.status=='success'){
					this.changedEmail.emit()
				} else {
					this.codeE = 4
				}
			},
			error => {
				this.loading = false
				this.codeE = 6
				console.log(error)
			}
		)
	}
}
