import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from  '@angular/material/dialog';
import { ImageEditerComponent} from "../image-editer/image-editer.component";
import { ApiService } from '../../services/api.service';
declare var $: any;

@Component({
  selector: 'app-avatar',
  templateUrl: './avatar.component.html',
  styleUrls: ['./avatar.component.scss']
})
export class AvatarComponent implements OnInit {
  croppedImage: any = '';
	myinfo = null
	filePath = ''
  constructor(
		private dialog:MatDialog,
		private apiservice: ApiService
  ) {
		this.filePath = apiservice.env.downUrl
	}

  ngOnInit(): void {
    this.myinfo = JSON.parse(localStorage.getItem('currentUser'))
  }
  triggerUpload(){
		$("#avatar-upload").click()
  }
  fileChangeEvent(event: any): void {
		let dialogConfig = new MatDialogConfig();
		dialogConfig['data'] = {event:event, croppedImage:this.croppedImage}

		const dialogRef = this.dialog.open(ImageEditerComponent, dialogConfig);
		dialogRef.afterClosed().subscribe(result => {
			if(result){
				this.croppedImage = result;
				this.apiservice.updateAvatar(this.croppedImage).subscribe(
					data =>{
						if(data.status=='success'){
							this.myinfo.avatar = data.avatar
							localStorage.setItem('currentUser', JSON.stringify(this.myinfo))
							this.apiservice.avatarEvent.emit(data.avatar)
						}
					},
					error=>{
						console.log(error)
					}
				)
			}
			$("#avatar-upload").val('')
		});
	}
}
