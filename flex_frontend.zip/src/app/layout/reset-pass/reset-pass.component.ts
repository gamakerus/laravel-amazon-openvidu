import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { AuthenticationService } from '../../services/authentication.service';

@Component({
	selector: 'app-reset-pass',
	templateUrl: './reset-pass.component.html',
	styleUrls: ['./reset-pass.component.scss']
})
export class ResetPassComponent implements OnInit {
	cur_pass=''
	new_pass=''
	con_pass=''
	codeE = 0
	loading = false
	resetFlag = false
	@Input() type:any
	@Output() changedPass = new EventEmitter<any>();
	constructor(
		private apiservice: ApiService,
		private authenticationservice : AuthenticationService,
	) { }

	ngOnInit(): void {
		if(this.type=='new')
			this.resetFlag = true
	}
	changePassword(){
		this.codeE = 0
		if(this.new_pass==''){
			this.codeE =2
			return false;
		}
		if(this.con_pass==''){
			this.codeE =3
			return false;
		}
		if(this.new_pass!=this.con_pass){
			this.codeE =4
			return false;
		}
		if(this.new_pass.length < 8){
			this.codeE =5
			return false;
		}
		this.loading = true
		this.apiservice.updatePassword(this.cur_pass, this.new_pass, this.resetFlag).subscribe(
			data => {
				this.loading = false
				if(data.status=='success'){
					if(this.type!='new'){
						this.changedPass.emit('pass')
					} else {
						this.authenticationservice.logout()
						window.location.href="/"
					}
					
				} else {
					this.codeE = 1
				}
			},
			error => {
				this.loading = false
				this.codeE = 6
			}
		)
	}
}
