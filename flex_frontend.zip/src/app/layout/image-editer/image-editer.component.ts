import { Component, OnInit, Inject} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from  '@angular/material/dialog';
import { ImageCroppedEvent } from 'ngx-image-cropper';
@Component({
  selector: 'app-image-editer',
  templateUrl: './image-editer.component.html',
  styleUrls: ['./image-editer.component.scss']
})
export class ImageEditerComponent implements OnInit {
  imageChangedEvent: any = '';
  croppedImage: any = '';
  constructor(
    private dialogRef:MatDialogRef<ImageEditerComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { 
    dialogRef.disableClose = true;
  }
  imageCropped(event: ImageCroppedEvent) {
    console.log(event);
    this.croppedImage = event.base64;
  }
  imageLoaded() {
      // show cropper
  }
  cropperReady() {
      // cropper ready
  }
  loadImageFailed() {
      // show message
  }
  ngOnInit(): void {
    this.imageChangedEvent = this.data['event'];
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
}
