import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-loading',
  templateUrl: './loading.component.html',
  styleUrls: ['./loading.component.scss']
})
export class LoadingComponent implements OnInit {
  @Input() color: string;
  constructor() { }

  ngOnInit(): void {
    if(!this.color || this.color==''){
      this.color = '#fff'
    }
  }

}
