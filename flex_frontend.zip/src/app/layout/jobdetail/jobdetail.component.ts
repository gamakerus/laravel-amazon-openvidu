import { Component, OnInit, Input } from '@angular/core';
import { ApiService } from '../../services/api.service';

@Component({
	selector: 'app-jobdetail',
	templateUrl: './jobdetail.component.html',
	styleUrls: ['./jobdetail.component.scss']
})
export class JobdetailComponent implements OnInit {
	userData = null
	userId = null
	services = [
		'CareGiver',
		'Nursing',
		'Therapy'
	]
	languages = []
	expertises = []
	licenses = []
	service_array = []
	weekname = []
	filePath = ''
	sub:any
	@Input() jobId:any
	constructor(
		private apiservice: ApiService,
	) {
		this.filePath = apiservice.env.downUrl
	}

	ngOnInit(): void {
		this.weekname = this.apiservice.weekName
		this.sub = this.apiservice.selectJobId.subscribe(
      id => {
				this.apiservice.getJobDetail(id).subscribe(
					data => {
						if(data.status=='success'){
							this.userData = data.jobdetail
							let licName = this.userData.licensename;
							let licImg = this.userData.licenseimg;
							if(licName)
								this.userData.licensename = licName.split("<||>")
							if(licImg)
								this.userData.licenseimg = licImg.split("<||>")
							console.log(this.userData)
							this.apiservice.getMisData(this.userData.service).subscribe(
								data => {
									for(let exp of data.exspec){
										this.expertises[exp.id] = exp.name
									}
									for(let ser of data.service){
										this.service_array[ser.id] = ser.name
									}
								},
								error => {
									console.log(error)
								}
							)
						}
						
					},
					error =>{
						console.log(error)
					}
				)
		})
	}
	ngOnDestroy(){
		if(this.sub)
    	this.sub.unsubscribe();
  }
}
