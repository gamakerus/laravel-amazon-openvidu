import { Component, OnInit, Inject, Output, EventEmitter } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from  '@angular/material/dialog';
import { ApiService } from '../../services/api.service';
import { ClipboardService } from 'ngx-clipboard'
declare var $: any;
@Component({
	selector: 'app-flexdlg',
	templateUrl: './flexdlg.component.html',
	styleUrls: ['./flexdlg.component.scss']
})
export class FlexdlgComponent implements OnInit {
	@Output() profileChange = new EventEmitter<any>();
	target=''
	schedule=[]
	weekName = []
	service=['CareGiver','Nursing','Therapy']
	subservice = []
	live_in = 0
	reason=''
	refID = ''
	constructor(
		private dialogRef:MatDialogRef<FlexdlgComponent>,
		private apiservice: ApiService,
		@Inject(MAT_DIALOG_DATA) public data:any,
		private _clipboardService: ClipboardService
	) {
		dialogRef.disableClose = true;
	}

	ngOnInit(): void {
		this.weekName = this.apiservice.weekName
		if(this.data.target=='schedule'){
			this.getSchedule()
		}
		if(this.data.target=="reason"){
			this.getReason(this.data.jobId)
		}
		if(this.data.target=="refund"){
			this.requestRefund(this.data.jobId)
		}
		if(this.data.target=="service4pay"){
			this.subservice = this.data.data.subservice.split('<||>')
		}
	}
	closeDlg(){
		this.dialogRef.close();
	}
	changeData(type){
		this.closeDlg()
		this.apiservice.closeDlg(type)
	}
	getSchedule(){
		this.apiservice.getUserSchedule(this.data.userId).subscribe(
			data=>{
				if(data.status=='success'){
					this.schedule = data.details
					this.live_in = data.live_in
				}
			}
		)
	}
	getReason(jobId){
		this.apiservice.getReason(jobId).subscribe(
			data=>{
				if(data.status=='success'){
					this.reason = data.reason
				}
			}
		)
	}
	processAfter(data){
		data.push(this.data.jobId)
		this.dialogRef.close(data);
	}
	requestRefund(jobid){
		this.apiservice.requestRefund(jobid).subscribe(
			data=>{
				if(data.status=='success'){
					this.refID = data.refid
				} else {
					this.refID = 'Sorry, please try again later.'
				}
			},
			error=>{
				console.log(error)
				this.refID = 'Sorry, please try again later.'
			}
		)
	}
	copy(){
		this._clipboardService.copyFromContent(this.refID)
	}
}
