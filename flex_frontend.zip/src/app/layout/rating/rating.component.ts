import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-rating',
  templateUrl: './rating.component.html',
  styleUrls: ['./rating.component.scss']
})
export class RatingComponent implements OnInit {
  review = ''
  rating = 0
  @Input() jobId:any
  @Output() confirmRating = new EventEmitter<any>();
  constructor(
    private apiservice: ApiService,
  ) { }

  ngOnInit(): void {
  }
  onRatingChange($event){
    this.rating = $event.rating
  }
  submitData(){
    this.apiservice.setJobReview(this.jobId, this.rating, this.review).subscribe(
      data=>{
        if(data.status=='success')
          this.confirmRating.emit([this.rating, this.review])
      }
    )
  }
}
