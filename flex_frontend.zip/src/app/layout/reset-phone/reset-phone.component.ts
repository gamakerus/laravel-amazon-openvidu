import { Component, OnInit, Input, Output, EventEmitter  } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { SearchCountryField, TooltipLabel, CountryISO } from 'ngx-intl-tel-input';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-reset-phone',
  templateUrl: './reset-phone.component.html',
  styleUrls: ['./reset-phone.component.scss']
})
export class ResetPhoneComponent implements OnInit {
  confirmPhoneFlag = 0
	resendPhoneFlag = 0
	codeE = 0
	eCode = ''
	sentFlag = false
	phoneErr = 0
	codeErr = 0
	loading = false
	phoneNumber = null
	countryiso = ''
	SearchCountryField = SearchCountryField;
	TooltipLabel = TooltipLabel;
	CountryISO = CountryISO;
	preferredCountries: CountryISO[] = [CountryISO.UnitedStates, CountryISO.UnitedKingdom];
	phoneForm = new FormGroup({
		phone: new FormControl(undefined, [Validators.required])
	});
	@Input() phone : String;
	@Input() countryISO : String;
	@Output() changedPhone = new EventEmitter<Number>();
	constructor(
		private apiservice: ApiService,
	) { }
  ngOnInit(): void {
		let phone_arr = this.phone.split(' ')
		this.phoneNumber = this.phone.replace(phone_arr[0], '')
  }
  confirmPhone(){
		this.codeE = 0
		this.phoneErr = 0
		if(this.phone==''){
			this.codeE = 1
			this.phoneErr = 1
			return false
		}
		this.confirmPhoneFlag = 1

		let phoneNumber = this.phoneNumber.internationalNumber
		this.apiservice.updatePhone(phoneNumber).subscribe(
			data => {
				if(data.status=='success'){
					this.confirmPhoneFlag = 2
					this.sentFlag = true
				}else if(data.status=='existed'){
					this.confirmPhoneFlag = 3
					this.codeE = 5
				} else {
					this.confirmPhoneFlag = 3
					this.codeE = 6
				}
			},
			error => {
				this.confirmPhoneFlag = 3
				this.codeE = 6
				console.log(error)
			}
		)
		
	}
	resendPhoneCode(){
		this.codeE = 0
		this.resendPhoneFlag = 1
		let phoneNumber = this.phoneNumber.internationalNumber
		this.apiservice.updatePhone(phoneNumber).subscribe(
			data => {
				if(data.status=='success'){
					this.resendPhoneFlag = 2
					this.sentFlag = true
				} else {
					this.resendPhoneFlag = 3
					this.codeE = 6
				}
			},
			error => {
				this.resendPhoneFlag = 3
				this.codeE = 6
				console.log(error)
			}
		)
	}
	changePhone(){
		this.codeE = 0
		this.codeErr = 0
		if(this.eCode==''){
			this.codeE = 3
			return false
		}
		this.loading = true
		
		let phoneNumber = this.phoneNumber.internationalNumber
		let countryISO = this.phoneNumber.countryCode
		this.apiservice.confirmPhone(this.eCode, phoneNumber, countryISO).subscribe(
			data => {
				if(data.status=='success'){
					this.loading = false
					this.changedPhone.emit()
				} else {
					this.loading = false
					this.codeE = 4
				}
			},
			error => {
				this.loading = false
				this.codeE = 6
				console.log(error)
			}
		)
	}
}
