import { Component, OnInit } from '@angular/core';


declare var $: any;
@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.scss']
})
export class ContactComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  toggleView(){
		if($(".call-info").hasClass('_closed')){
			$(".open-button").fadeOut(300)
			setTimeout(function(){
				$(".call-body").fadeIn(300)
			},300)
			$(".call-info").removeClass('_closed');
			$(".call-info").addClass('_opened');
		}
		
	}
	closeView(){
		$(".call-body").fadeOut(300)
		setTimeout(function(){
			$(".open-button").fadeIn(600)
		},300)
		$(".call-info").addClass('_closed');
		$(".call-info").removeClass('_opened');
	}
}
