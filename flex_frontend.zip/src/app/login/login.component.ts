import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from  '@angular/material/dialog';
import { ApiService } from '../services/api.service';
import { AuthenticationService } from '../services/authentication.service';
import { first } from 'rxjs/operators';
import { SocialAuthService } from "angularx-social-login";
import { FacebookLoginProvider, GoogleLoginProvider } from "angularx-social-login";
import { Router } from '@angular/router';
declare var $: any;
@Component({
	selector: 'app-login',
	templateUrl: './login.component.html',
	styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
	loading = false;
	submitted = false;
	inputVal = {email:'', password:'', authToken:''};
	inputValErr = {email:0, password:0}
	failed = false;
	not_allowed = false;
	userType = 0;
	step =1;
	pending = false
	socialFlag = false
	loginstart = false
	socialLoading = false
	constructor(
		private dialogRef:MatDialogRef<LoginComponent>,
		private authenticationService: AuthenticationService,
		private apiservice: ApiService,
		private authService: SocialAuthService,
		private router: Router,
		@Inject(MAT_DIALOG_DATA) public data:any
	) { 
		dialogRef.disableClose = true;
		if(data && data.target=="workwithus"){
			this.step = 4
		}
	}
	
	ngOnInit(): void {
	}
	selectType(type){
		this.userType = type
	}
	closeAlert(){
		this.failed = false;
	}
	goNextForm(step){
		this.step = step
	}
	backFromSignup($event){
		if(this.data && this.data.target=="workwithus"){
			if($event==1)
				this.goNextForm(1);
			else
				this.closeDlg()
		} else {
			this.goNextForm(2);
		}
	}
	closeDlg(){
		this.dialogRef.close();
	}
	loginSubmit(){
		this.loading=true
		this.inputValErr = {email:0, password:0}
		this.failed = false;
		if(this.inputVal.email==''){
			this.inputValErr.email = 1
			this.failed = true;
		} else {
			if(!this.apiservice.validateEmail(this.inputVal.email)){
				this.inputValErr.email = 2
				this.failed = true;
			}
		}
		if(!this.socialFlag && this.inputVal.password==''){
			this.inputValErr.password = 1
			this.failed = true;
		}
		if(this.failed){
			this.loading=false
			return false
		}
		let password = this.inputVal.password
		if(this.socialFlag){
			password = this.inputVal.authToken
		}
		this.authenticationService.login(this.inputVal.email, password, this.socialFlag)
			.pipe(first())
			.subscribe(
				data => {
					this.loginstart = false
					this.loading=false
					if(data.status=='failed'){
						this.inputValErr.email = 3
						this.inputValErr.password = 3
						this.failed = true;
						return ;
					}
					if(data.status=='pending'){
						this.pending = true
						if(data.userdata.usertype==1){
							this.step = 3
						} else {
							this.step = 4
						}
						return ;
					}
					if(data.status=='illegal'){
						this.inputValErr.email = 3
						this.inputValErr.password = 3
						this.failed = true;
						return ;
					}
					if(data.status=='not_approved'){
						this.router.navigate(['/under-review']);
						localStorage.removeItem('redirect_url');
						this.closeDlg()
						return ;
					}
					if(data.status=='not_completed'){
						// this.router.navigate(['/provider/profile']);
						window.location.href="provider/profile"
						this.closeDlg()
						return ;
					}
					if(data.status=='not_paid'){
						localStorage.setItem('paid','not');
						window.location.href="provider/profile"
						this.closeDlg()
						return ;
					}
					let returnUrl = localStorage.getItem('redirect_url');
					if(returnUrl && returnUrl!=''){
						window.location.href=returnUrl
						localStorage.removeItem('redirect_url');
					}else
						window.location.href="profile/"+data.userdata.fname+" "+data.userdata.lname

				},
				error => {
					this.loginstart = false
					this.failed = true;
					this.inputValErr.email = 3
					this.loading = false;
				});
	}
	socialSignin(social){
		if(this.socialLoading)
			return false
		this.loginstart = true
		this.socialLoading = true
		if(social=='google'){
			this.authService.signIn(GoogleLoginProvider.PROVIDER_ID).catch(reason=>{
				this.socialLoading = false
			});
		} else {
			this.authService.signIn(FacebookLoginProvider.PROVIDER_ID);
		}
		this.authService.authState.subscribe((user) => {
			this.socialLoading = false
			this.inputVal.email = user.email
			if(user.idToken && user.idToken!='')
				this.inputVal.authToken = user.idToken
			else
				this.inputVal.authToken = user.id
			this.inputVal.password = ''
			this.socialFlag = true
			this.loginSubmit()
		});
	}
}
