import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

import { AuthenticationService } from '../services/authentication.service';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {
	constructor(
		private router: Router,
		private authenticationService: AuthenticationService
	) {}

	canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
		
		const currentUser = this.authenticationService.currentUserValue;
		if (currentUser) {
			let expirationDate = localStorage.getItem('expirationDate');
			const currentDate = new Date().getTime();
			let temp_user = localStorage.getItem('temp_user')
			if(temp_user && temp_user=='true'){
				if(route.routeConfig.path!='provider/profile'){
					this.router.navigate(['/provider/profile']);
				}
			}
			// authorised so return true
			if(currentDate < parseInt(expirationDate)){
				expirationDate = new Date(new Date().getTime() + 30*60*1000).getTime().toString();
				localStorage.setItem('expirationDate', expirationDate);
				return true;
			}
		}
		localStorage.removeItem('currentUser');
		localStorage.removeItem('expirationDate');
		localStorage.removeItem('user_token');
		localStorage.removeItem('reset_flag');
		localStorage.setItem('redirect_url', state.url);
		// not logged in so redirect to login page with the return url
		this.router.navigate(['/logout'], { queryParams: { returnUrl: state.url }});
		return false;
	}
	
}