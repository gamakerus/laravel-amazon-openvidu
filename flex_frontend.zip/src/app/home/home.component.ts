import { Component, OnInit, HostListener } from '@angular/core';
import { ApiService } from '../services/api.service';
import { SearchCountryField, TooltipLabel, CountryISO } from 'ngx-intl-tel-input';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { SearchfilterComponent} from "../client/searchfilter/searchfilter.component";
import { Router, ActivatedRoute } from '@angular/router';
import { LoginComponent} from "../login/login.component";
import { SocialAuthService } from "angularx-social-login";
import { FacebookLoginProvider, GoogleLoginProvider } from "angularx-social-login";
declare var $: any;
@Component({
	selector: 'app-home',
	templateUrl: './home.component.html',
	styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
	public goToTopBtnFlag = false
	SearchCountryField = SearchCountryField;
	TooltipLabel = TooltipLabel;
	CountryISO = CountryISO;
	preferredCountries: CountryISO[] = [CountryISO.UnitedStates, CountryISO.UnitedKingdom];
	phoneForm = new FormGroup({
		phone: new FormControl(undefined, [Validators.required])
	});
	user = null
	center = {lat: 24, lng: 12};
	constructor(
		private route: ActivatedRoute,
		private router: Router,
		private apiservice: ApiService,
		private dialog:MatDialog,
		private authService: SocialAuthService,
	) { }
	@HostListener("window:scroll", [])
	onWindowScroll() {
		if ($(window).scrollTop() > 220) { // Set position from top to add class
			this.goToTopBtnFlag = true;
		}
		else {
			this.goToTopBtnFlag = false;
		}
	}
	scrollToTop(){
		$('html, body').animate({scrollTop: 0}, 800);
	}
	
	ngOnInit(): void {
		if(localStorage.getItem('currentUser')!='undefined'){
			this.user = JSON.parse(localStorage.getItem('currentUser'));
		}
		this.apiservice.currentMenu = 'home'
		if(this.user){
			this.router.navigate(['profile/'+this.user.fname + ' '+this.user.lname]);
		} else {
			localStorage.removeItem('paid');
		}
		
	}
	findCareGiver() {
		const dialogConfig = new MatDialogConfig();
		dialogConfig.autoFocus = true;
		this.dialog.open(SearchfilterComponent, dialogConfig);
	}
	workwithus() {
		const dialogConfig = new MatDialogConfig();
		dialogConfig.data = {target:"workwithus"}
		this.dialog.open(LoginComponent, dialogConfig);
	}
	socialSignin(social){
		this.authService.signIn(GoogleLoginProvider.PROVIDER_ID);
	}
}
