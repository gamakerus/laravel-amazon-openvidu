import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { MatDialog, MatDialogConfig } from  '@angular/material/dialog';
import { ImageEditerComponent} from "../../layout/image-editer/image-editer.component";
import { NativeDateAdapter, DateAdapter,	MAT_DATE_FORMATS } from '@angular/material/core';
import { formatDate } from '@angular/common';
import { SearchCountryField, TooltipLabel, CountryISO } from 'ngx-intl-tel-input';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AuthenticationService } from '../../services/authentication.service';
import { first } from 'rxjs/operators';
import { ApiService } from '../../services/api.service';
import { SocialAuthService } from "angularx-social-login";
import { FacebookLoginProvider, GoogleLoginProvider } from "angularx-social-login";
 
declare var $: any;
export const PICK_FORMATS = {
	parse: {dateInput: {month: 'short', year: 'numeric', day: 'numeric'}},
	display: {
		dateInput: 'input',
		monthYearLabel: {year: 'numeric', month: 'short'},
		dateA11yLabel: {year: 'numeric', month: 'long', day: 'numeric'},
		monthYearA11yLabel: {year: 'numeric', month: 'long'}
	}
};

class PickDateAdapter extends NativeDateAdapter {
	format(date: Date, displayFormat: Object): string {
		if (displayFormat === 'input') {
			return formatDate(date,'MM/dd/yyyy',this.locale);;
		} else {
			return date.toDateString();
		}
	}
}
@Component({
	selector: 'app-client',
	templateUrl: './client.component.html',
	styleUrls: ['./client.component.scss'],
	providers: [
		{provide: DateAdapter, useClass: PickDateAdapter},
		{provide: MAT_DATE_FORMATS, useValue: PICK_FORMATS}
	]
})
export class ClientComponent implements OnInit {
	step =3;
	croppedImage: any = '';
	showCropper = false;
	terms = false;
	SearchCountryField = SearchCountryField;
	TooltipLabel = TooltipLabel;
	CountryISO = CountryISO;
	preferredCountries: CountryISO[] = [CountryISO.UnitedStates, CountryISO.UnitedKingdom];
	phoneForm = new FormGroup({
		phone: new FormControl(undefined, [Validators.required])
	});
	formdata = {
		name:'',
		email:'',
		password:'',
		dob:null,
		phone:'',
		avatar:null,
		paymethod:0,
		terms:false,
		countryISO:'',
		fname:'',
		lname:'',
		authToken:null,
		socialFlag : false
	}
	birthday=null
	formdataErr = {
		name:0,
		email:0,
		password:0,
		dob:0,
		phone:0,
		avatar:0,
		paymethod:0,
		terms:0,
		codeE:0,
		codeP:0,
	}
	codeE=''
	codeP=''
	usertoken = null
	loading=false
	failed =false
	sendPhoneFlag = 0
	resendEmailFlag = 0
	sSignUpFlag = false
	socialLoading = false
	@Input() status : Boolean;
	@Input() parent : String;
	@Output() backToParent: EventEmitter <any> = new EventEmitter();
	@Output() close: EventEmitter <any> = new EventEmitter();
	constructor(
		private dialog:MatDialog,
		private authenticationService: AuthenticationService,
		private apiservice: ApiService,
		private authService: SocialAuthService
		// private authService: SocialAuthService
	) {}

	ngOnInit(): void {
		if(this.status)
			this.step = 5
	}
	goNextForm(step, validate){
		this.formdataErr = {
			name:0,
			email:0,
			password:0,
			dob:0,
			phone:0,
			avatar:0,
			paymethod:0,
			terms:0,
			codeE:0,
			codeP:0,
		}
		this.failed = false
		if(step < 3){
			this.backToParent.emit(step);
			return;
		}
		if(validate){
			if(step==4){
				if(this.formdata.email==''){
					this.formdataErr.email = 1
					this.failed = true
					return false
				} else {
					if(! this.sSignUpFlag && !this.apiservice.validateEmail(this.formdata.email)){
						this.formdataErr.email = 2
						this.failed = true
						return false
					}
				}
				if(!this.formdata.socialFlag){
					if(this.formdata.password==''){
						this.formdataErr.password = 1
						this.failed = true
						return false
					} else {
						if(this.formdata.password.length <8 ){
							this.formdataErr.password = 2
							this.failed = true
							return false
						}
					}
					if(!this.terms){
						this.formdataErr.terms = 1
						return false
					}
				}
			}
		}
		this.step = step
	}
	fileChangeEvent(event: any): void {
		this.imageEditerShow(event);
		
	}
	triggerUpload(){
		$("#avatar-upload").click()
	}
	imageEditerShow(event) {
		let dialogConfig = new MatDialogConfig();
		dialogConfig['data'] = {event:event, croppedImage:this.croppedImage}
		// dialogConfig.autoFocus = true;
		const dialogRef = this.dialog.open(ImageEditerComponent, dialogConfig);
		dialogRef.afterClosed().subscribe(result => {
			if(result){
				this.croppedImage = result;
				this.formdata.avatar = result;
			}
			$("#avatar-upload").val('')
		});
	}
	socialSignup(target){
		this.sSignUpFlag = true
		if(this.socialLoading)
			return false
		this.socialLoading = true
		if(target=='google'){
			this.authService.signIn(GoogleLoginProvider.PROVIDER_ID).catch(reason=>{
				this.socialLoading = false
			});
		} else {
			this.authService.signIn(FacebookLoginProvider.PROVIDER_ID);
		}
		this.authService.authState.subscribe((user) => {
			this.socialLoading = false
			this.formdata.fname = user.firstName
			this.formdata.lname = user.lastName
			this.formdata.email = user.email
			this.formdata.avatar = user.photoUrl
			this.formdata.socialFlag = true
			if(user.idToken && user.idToken!='')
				this.formdata.authToken = user.idToken
			else
				this.formdata.authToken = user.id

			this.goNextForm(4, false)
		},
		error=>{
			this.socialLoading = false
			console.log(error)
		});
	}
	submitForm(){
		this.formdataErr = {
			name:0,
			email:0,
			password:0,
			dob:0,
			phone:0,
			avatar:0,
			paymethod:0,
			terms:0,
			codeE:0,
			codeP:0,
		}
		this.failed = false
		if(this.phoneForm.value.phone==null){
			this.formdataErr.phone = 1
			this.failed = true
			return false
		}
		if(this.birthday=='' || this.birthday==null){
			this.formdataErr.dob = 1
			this.failed = true
			return false
		}
		if(this.formdata.paymethod==0){
			this.formdataErr.paymethod = 1
			this.failed = true
			return false
		}
		this.loading = true
		this.formdata.phone = this.phoneForm.value.phone.internationalNumber
		this.formdata.countryISO = this.phoneForm.value.phone.countryCode
		this.formdata.dob = this.birthday.toDateString()
		this.authenticationService.register(this.formdata)
			.pipe(first())
			.subscribe(
				data => {
					this.loading = false
					if(data.status=='success'){
						this.usertoken = data.token
						if(this.formdata.socialFlag)
							this.goNextForm(6, false)
						else
							this.goNextForm(5, false)
						return true
					}
					this.failed = true
					this.formdataErr.name = 1
					return false;
					// this.router.navigate(['/editor']);
				},
				error => {
					if(error.error.errors && error.error.errors.email!=''){
						this.formdataErr.name = 2
					} else{
						this.formdataErr.name = 1
					}
					this.loading = false
					this.failed = true
					
					return false;
				});
		
	}
	confirmSubmit(){
		this.formdataErr = {
			name:0,
			email:0,
			password:0,
			dob:0,
			phone:0,
			avatar:0,
			paymethod:0,
			terms:0,
			codeE:0,
			codeP:0,
		}
		this.failed = false
		if(!this.formdata.socialFlag){
			if(this.codeE==''){
				this.formdataErr.codeE = 1
				this.failed = true
				return false
			}
		} else {
			this.codeE=''
		}
		
		if(this.codeP==''){
			this.formdataErr.codeP = 1
			this.failed = true
			return false
		}
		this.authenticationService.clientVerify('both', this.codeE, this.codeP).subscribe(
			data => {
				if(data.status=='success'){
					window.location.href="search/caregivers"
					// this.close.emit();
				} else {
					this.formdataErr.name = 1
					this.failed = true
				}
				return false;
			},
			error => {
				this.formdataErr.name = 1
				this.failed = true
			});
	}
	resendEmail(){
		this.resendEmailFlag = 1
		this.authenticationService.singleReq('email_resend', this.formdata.email).subscribe(
			data => {
				if(data.status=='success'){
					this.resendEmailFlag = 2
				} else {
					this.resendEmailFlag = 3
				}
				return false;
			},
			error => {
				this.resendEmailFlag = 3
				console.log(error)
			});
	}
	resendPhone(){
		this.failed = false
		this.sendPhoneFlag = 1
		this.authenticationService.singleReq('phone_recend', '').subscribe(
			data => {
				if(data.status=='success'){
					this.sendPhoneFlag = 2
				} else {
					this.sendPhoneFlag = 3
				}
				return false;
			},
			error => {
				this.sendPhoneFlag = 3
				console.log(error)
			});
	}
	login(){
		if(this.parent=='searchfilter')
			this.apiservice.loginEvent.emit()
		else
			this.goNextForm(1, false)
	}
}
