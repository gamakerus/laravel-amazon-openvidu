import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { SearchCountryField, TooltipLabel, CountryISO } from 'ngx-intl-tel-input';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AuthenticationService } from '../../services/authentication.service';
import { first } from 'rxjs/operators';
import { ApiService } from '../../services/api.service';
import { Router, ActivatedRoute } from '@angular/router';
import { SocialAuthService } from "angularx-social-login";
import { FacebookLoginProvider, GoogleLoginProvider } from "angularx-social-login";

@Component({
	selector: 'app-provider',
	templateUrl: './provider.component.html',
	styleUrls: ['./provider.component.scss']
})
export class ProviderComponent implements OnInit {
	step =3;
	terms = false;
	SearchCountryField = SearchCountryField;
	TooltipLabel = TooltipLabel;
	CountryISO = CountryISO;
	preferredCountries: CountryISO[] = [CountryISO.UnitedStates, CountryISO.UnitedKingdom];
	phoneForm = new FormGroup({
		phone: new FormControl(undefined, [Validators.required])
	});
	email = '';
	email_confirm = '';
	change_email_flag = false
	email_code = ''
	password=''
	password_confirm = ''
	phone_number=''
	phone_code=''
	phone_verified = false
	emailErr = 0
	passErr = 0
	termsErr = 0
	codeE = 0
	otherE = 0
	phoneE = 0
	codeP = 0
	failed = false
	loading = false
	sendPhoneFlag = 0
	resendEmailFlag = 0
	sendCodeFlag = 0
	formdata = {
		fname:'',
		lname:'',
		avatar:null,
		email:'',
		socialFlag:false,
		authToken:null
	}
	socialLoading = false
	@Input() status : Boolean;
	@Output() backToParent: EventEmitter <any> = new EventEmitter();
	@Output() close: EventEmitter <any> = new EventEmitter();
	constructor(
		private authenticationService: AuthenticationService,
		private apiservice: ApiService,
		private route: ActivatedRoute,
		private router: Router,
		private authService: SocialAuthService
	) { }

	ngOnInit(): void {
		if(this.status)
			this.step = 6
	}
	goNextForm(step){
		if(step < 3){
			this.backToParent.emit(step);
			return;
		}
		this.step = step
	}
	sendEmail(){
		this.emailErr = 0
		this.passErr = 0
		this.termsErr = 0
		this.otherE = 0
		this.failed = false
		let type = 'email';
		if(this.email==''){
			this.emailErr = 1
			this.failed = true
			return false
		} else if(!this.apiservice.validateEmail(this.email)){
			this.emailErr = 2
			this.failed = true
			return false
		} else if(this.email!=this.email_confirm){
			this.emailErr = 3
			this.failed = true
			return false
		}
		if(! this.terms){
			this.termsErr = 1
			return false
		}
		this.loading = true
		if(this.change_email_flag)
			type = 'email_change'
		this.authenticationService.singleReq(type, this.email)
		.pipe(first())
		.subscribe(
			data => {
				console.log(data)
				this.loading = false
				if(data.status=='success'){
					this.goNextForm(4)
					return true
				}
				this.otherE = 1
				this.failed = true
				return false;
			},
			error => {
				this.otherE = 1
				this.loading = false
				this.failed = true
				console.log(error)
			});
	}
	resendEmail(){
		this.resendEmailFlag = 1
		this.authenticationService.singleReq('email_resend', this.email).subscribe(
			data => {
				if(data.status=='success'){
					this.resendEmailFlag = 2
				} else {
					this.resendEmailFlag = 3
				}
				return false;
			},
			error => {
				this.resendEmailFlag = 3
				console.log(error)
			});
	}
	change_email(){
		this.change_email_flag = true
		this.goNextForm(3)
	}
	sendEmailCode(){
		this.codeE = 0
		this.failed = false
		if(this.email_code==''){
			this.codeE = 1
			this.failed = true
			return false
		}
		this.loading = true
		this.authenticationService.singleReq('email_code', this.email_code).subscribe(
			data => {
				this.loading = false
				if(data.status=='success'){
					this.goNextForm(5)
				} else {
					this.codeE = 1
					this.failed = true
				}
				return false;
			},
			error => {
				this.loading = false
				console.log(error)
			});
	}
	sendPassword(){
		this.otherE = 0
		this.passErr = 0
		this.failed = false
		if(this.password==''){
			this.passErr = 1
			this.failed = true
			return false
		} else if(this.password.length < 8){
			this.passErr = 2
			this.failed = true
			return false
		} else if(this.password!=this.password_confirm){
			this.passErr = 3
			this.failed = true
			return false
		}
		this.loading = true
		this.authenticationService.singleReq('password', this.password).subscribe(
			data => {
			this.loading = false
			if(data.status=='success'){
					this.goNextForm(6)
					return true
				}
				this.failed = true
				return false;
			},
			error => {
				this.loading = false
				this.failed = true
				this.otherE = 1
			});
	}
	sendPhone(){
		this.failed = false
		this.phoneE = 0
		this.codeP = 0
		this.otherE = 0
		this.sendPhoneFlag = 1
		if(this.phoneForm.value.phone==null){
			this.failed = true
			this.phoneE = 1
			return false
		}
		this.authenticationService.singleReq('phone', this.phoneForm.value.phone).subscribe(
			data => {
				this.sendPhoneFlag = 2
				if(data.status=='success'){
					this.phone_verified = true
				} else {
					this.phoneE = 1
					this.failed = true
				}
				return false;
			},
			error => {
				this.sendPhoneFlag = 3
				this.otherE = 1
				this.failed = true
			});
	}
	resendPhone(){
		this.failed = false
		this.otherE = 0
		this.sendCodeFlag = 1
		this.authenticationService.singleReq('phone_recend', '').subscribe(
			data => {
				if(data.status=='success'){
					this.sendCodeFlag = 2
				} else {
					this.otherE = 1
					this.failed = true
					this.sendCodeFlag = 3
				}
				return false;
			},
			error => {
				this.sendCodeFlag = 3
				this.otherE = 1
				this.failed = true
				console.log(error)
			});
	}
	confirmSubmit(){
		this.failed = false
		this.codeP = 0
		this.otherE = 0
		if(this.phone_code==''){
			this.codeP = 1
			this.failed = true
			return false
		}
		if(!this.phone_verified){
			this.phoneE = 2
			this.failed = true
			return false
		}
		this.loading = true
		this.authenticationService.singleReq('phone_code', this.phone_code).subscribe(
			data => {
				this.loading = false
				if(data.status=='success'){
					this.close.emit();
					// this.router.navigate(['provider/profile']);
					window.location.href="provider/profile"
				} else {
					this.codeP = 1
					this.failed = true
				}
				return false;
			},
			error => {
				this.loading = false
				this.otherE = 1
				this.failed = true
				console.log(error)
			});
	}
	socialSignup(target){
		if(this.socialLoading)
			return false
		this.socialLoading = true
		if(target=='google'){
			this.authService.signIn(GoogleLoginProvider.PROVIDER_ID).catch(reason=>{
				this.socialLoading = false
			});
		}else{
			this.authService.signIn(FacebookLoginProvider.PROVIDER_ID);
		}
		this.authService.authState.subscribe((user) => {
			this.socialLoading = false
			this.formdata.fname = user.firstName
			this.formdata.lname = user.lastName
			this.formdata.email = user.email
			this.formdata.avatar = user.photoUrl
			if(user.idToken && user.idToken!='')
				this.formdata.authToken = user.idToken
			else
				this.formdata.authToken = user.id
			this.formdata.socialFlag = true
			this.authenticationService.singleReq('social', this.formdata).subscribe(
				data => {
					this.loading = false
					if(data.status=='success'){
						this.goNextForm(6)
					} else {
						this.otherE = 1
						this.failed = true
					}
					return false;
				},
				error => {
					this.loading = false
					this.otherE = 1
					this.failed = true
					return false
				});
			
		});
	}
}
