import { Injectable, Output, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';
@Injectable({
	providedIn: 'root'
})
export class ApiService {
	public currentMenu = 'home'
	public weekName = ['Monday','Tuesday','Wednesday', 'Thursday', 'Friday', 'Saturday','Sunday']
	public env
	@Output() flexDlgClose = new EventEmitter<any>();
	@Output() findCareGiver = new EventEmitter<any>();
	@Output() selectUserId = new EventEmitter<any>();
	@Output() selectJobId = new EventEmitter<any>();
	@Output() hideMenu = new EventEmitter<any>();
	@Output() logoutEvent = new EventEmitter<any>();
	@Output() loginEvent = new EventEmitter<any>();
	@Output() avatarEvent = new EventEmitter<any>();
	constructor(
		private http: HttpClient
	) {
		this.env = environment
	}
	validateEmail(inputText)
	{
		if(!inputText || inputText=='')
			return false;
		var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
		if(inputText.match(mailformat)){
			return true;
		}else{
			return false;
		}
	}
	logout(){
		this.logoutEvent.emit()
	}
	closeDlg(val){
		this.flexDlgClose.emit(val)
	}
	findprovider(val){
		this.findCareGiver.emit(val)
	}
	selectUser(id){
		this.selectUserId.emit(id)
	}
	selectJob(id){
		this.selectJobId.emit(id)
	}
	hideHeader(){
		this.hideMenu.emit()
	}
	postFile(fileToUpload: File[]): Observable<boolean> {
    const endpoint = `${environment.apiUrl}getfile`;
		const formData: FormData = new FormData();
		let user_token = localStorage.getItem('user_token');
		formData.append('token', user_token)
		for(let i=0; i<fileToUpload.length;i++){
			formData.append(fileToUpload[i]['id'], fileToUpload[i]['file'], fileToUpload[i]['file'].name);
		}
    
    return this.http
      .post(endpoint, formData)
      .pipe(map(() => { return true; }))
	}
	getAddress(lat,lon){
		let url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lon}&key=${environment.googleAPI}`
		return this.http.get<any>(url);
	}
	getGeocode(address){
		let url = `https://maps.googleapis.com/maps/api/geocode/json?address=${address}&key=${environment.googleAPI}`
		return this.http.get<any>(url);
	}
	getMisData(type){
		return this.http.post<any>(`${environment.apiUrl}signupgprofile`, {servicetype:type});
	}
	getProviderAround(lat, lng){
		return this.http.post<any>(`${environment.apiUrl}getcntPro`, {lat, lng});
	}
	getRelation(){
		return this.http.get<any>(`${environment.apiUrl}getptrelation`);
	}
	getUserProfileData(){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}profileview`, {token:user_token});
	}
	getProviderList(search){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}searchcaregiver`, {token:user_token, sort:search.sort, filter:search.filter, lat:search.latitude, lng:search.longitude, data:search});
	}
	setUserPofileData(userdata){
		let data = {
			fname:userdata.fname, 
			lname:userdata.lname,
			gender:userdata.gender,
			address:userdata.address,
			dob:userdata.dob.toDateString(),
			lat:userdata.lat,
			long:userdata.long,
		}
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}profileupdate`, {token:user_token, userdata:data});
	}
	updateAvatar(avatar){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}avatarupdate`, {token:user_token, avatar});
	}
	updateCoverImg(img){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}coverimgupdate`, {token:user_token, coverimg:img});
	}
	updateBio(bio){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}bioupdate`, {token:user_token, bio});
	}
	updateEmail(email){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}emailupdate`, {token:user_token, email});
	}
	resendCode(){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}emailresend`, {token:user_token});
	}
	confirmEmail(code){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}emailverified`, {token:user_token, code});
	}
	updatePassword(curPass, newPass, resetFlag){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}passwordupdate`, {token:user_token, curPass, newPass, resetFlag});
	}
	updatePhone(phone){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}phoneupdate`, {token:user_token, phone});
	}
	
	confirmPhone(code, phone, countryiso){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}phoneverified`, {token:user_token, code, phone, countryiso});
	}
	updateQualification(userdata){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}qualificationupdate`, {token:user_token, userdata});
	}
	updatePrice(price){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}priceupdate`, {token:user_token, price});
	}
	getUserInfo(id){
		return this.http.post<any>(`${environment.apiUrl}chosenProfile`, {id});
	}
	verifyToken(token){
		return this.http.post<any>(`${environment.apiUrl}verifytoken`, {token});
	}
	getUserMisInfo(id){
		return this.http.post<any>(`${environment.apiUrl}chosenlist`, {id});
	}
	getReceipt(data){
		return this.http.post<any>(`${environment.apiUrl}setcost`, {data});
	}
	getInterviewSchedule(id){
		return this.http.post<any>(`${environment.apiUrl}interviewlist`, {id});
	}
	checkInterviewSchedule(id, settime){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}checkinterview`, {token:user_token, id, settime});
	}
	setInterviewSchedule(id, settime){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}confirminterview`, {token:user_token, id, settime});
	}
	setCost(data){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}setcost`, {token:user_token, data});
	}
	getClientInterviews(){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}interviewforclient`, {token:user_token});
	}
	getProviderInterviews(){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}interviewforprovider`, {token:user_token});
	}
	getSchedule(){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}viewschedule`, {token:user_token});
	}
	setSchedule(data){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}setschedule`, {token:user_token, data});
	}
	checkNotifications(){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}checkunread`, {token:user_token});
	}
	getNotifications(page){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}viewnotification`, {token:user_token, page});
	}
	getUserSchedule(id){
		return this.http.post<any>(`${environment.apiUrl}scheduledetails`, {id});
	}
	acceptInterview(id){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}acceptinterview`, {token:user_token, id});
	}
	createRoom(id){
		return this.http.post<any>(`${environment.apiUrl}createintroom`, {id});
	}
	getStripeKey(){
		return this.http.get<any>(`${environment.apiUrl}getstripekey`);
	}
	requestPay(stripe_token, jobid){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}paystep`, {token:user_token, stripe_token, jobid});
	}
	requestSignupPay(stripe_token){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}profilepay`, {token:user_token, stripe_token});
	}
	requestInterviewPay(stripe_token){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}payinterview`, {token:user_token, stripe_token});
	}
	requestJob(data, search){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}createjob`, {token:user_token, data, search});
	}
	getOngoingServices(){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}ongoingservice`, {token:user_token});
	}
	getFinishedServices(page){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}finishedservice`, {token:user_token,page});
	}
	getcanceledServices(page){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}canceledservice`, {token:user_token, page});
	}
	getIncomingServices(){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}incomingservice`, {token:user_token});
	}

	getOngoingJobs(){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}ongoingjob`, {token:user_token});
	}
	getFinishedJobs(page){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}previousjob`, {token:user_token, page});
	}
	getcanceledJobs(){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}canceledjob`, {token:user_token});
	}
	getIncomingJobs(){
		let user_token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}incomingjob`, {token:user_token});
	}
	acceptJob(jobid){
		return this.http.post<any>(`${environment.apiUrl}acceptjob`, {jobid});
	}

	getRejectReason(){
		let user_token = localStorage.getItem('user_token');
		return this.http.get<any>(`${environment.apiUrl}cancelreason`);
	}
	getRejectReason4Interview(){
		let user_token = localStorage.getItem('user_token');
		return this.http.get<any>(`${environment.apiUrl}canintreason`);
	}
	setRejectReason(data, target){
		let user = JSON.parse(localStorage.getItem('currentUser'));
		let token = localStorage.getItem('user_token');
		if(target=='service')
			return this.http.post<any>(`${environment.apiUrl}canceljob`, {data});
		if(target=='job')
			return this.http.post<any>(`${environment.apiUrl}rejectjob`, {data});
		if(target=='interview'){
			if(user.usertype==2)
				return this.http.post<any>(`${environment.apiUrl}cancelintbyprovider`, {data, token});
			if(user.usertype==1)
				return this.http.post<any>(`${environment.apiUrl}cancelintbyclient`, {data, token});
		}
	}

	getJobDetail(jobid){
		let myinfo = JSON.parse(localStorage.getItem('currentUser'))
		return this.http.post<any>(`${environment.apiUrl}jobdetail`, {usertype:myinfo.usertype, jobid});
	}
	setJobReview(jobid, rating, review){
		let myinfo = JSON.parse(localStorage.getItem('currentUser'))
		return this.http.post<any>(`${environment.apiUrl}review`, {usertype:myinfo.usertype, jobid, rating, review});
	}
	getReason(jobid){
		return this.http.post<any>(`${environment.apiUrl}viewreason`, {jobid});
	}
	requestRefund(jobid){
		return this.http.post<any>(`${environment.apiUrl}requestrefund`, {jobid});
	}
	goInterview(intid){
		let token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}gotoint`, {token, intid});
	}
	leaveInterview(intid){
		let token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}leaveint`, {token, intid});
	}
	setReadNotification(id){
		let token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}readnotification`, {token, id});
	}
	getDescription(type){
		return this.http.post<any>(`${environment.apiUrl}getdescription`, {type});
	}
	getPaymentStatus(){
		let token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}paydetail`, {token});
	}
	setPayment(){
		let token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}setpayaccount`, {token});
	}
	getClientTransaction(page){
		let token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}translist`, {token, page});
	}
	getProviderTransaction(page){
		let token = localStorage.getItem('user_token');
		return this.http.post<any>(`${environment.apiUrl}transhistory`, {token, page});
	}
}
