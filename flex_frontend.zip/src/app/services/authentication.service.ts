import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

import { User, RegUser } from '../models/user';

@Injectable({ providedIn: 'root' })
export class AuthenticationService {
	private currentUserSubject: BehaviorSubject<User>;
	public currentUser: Observable<User>;

	constructor(private http: HttpClient) {
		if(localStorage.getItem('currentUser')!='undefined'){
			this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('currentUser')));
			this.currentUser = this.currentUserSubject.asObservable();
		}
	}

	public get currentUserValue(): User {
		return this.currentUserSubject.value;
	}
	register(reguser: RegUser) {
		return this.http.post<any>(`${environment.apiUrl}signupc`, reguser)
			.pipe(map(user => {
				localStorage.setItem('pre_token', user.token);
				return user;
			}));
	}
	login(email, password, socialFlag) {
		return this.http.post<any>(`${environment.apiUrl}login`, { email, password, socialFlag })
			.pipe(map(user => {
				// store user details and jwt token in local storage to keep user logged in between page refreshes
				const expirationDate = new Date(new Date().getTime() + 30*60*1000).getTime().toString();
				if(user.status=='success'){
					localStorage.setItem('currentUser', JSON.stringify(user.userdata));
					localStorage.setItem('user_token', user.token);
					localStorage.setItem('expirationDate', expirationDate);
					this.currentUserSubject.next(user);
				}
				if(user.status=='not_completed' || user.status=='not_paid'){
					localStorage.setItem('currentUser', JSON.stringify(user.userdata));
					localStorage.setItem('user_token', user.token);
					localStorage.setItem('expirationDate', expirationDate);
					localStorage.setItem('temp_user', "true");
					this.currentUserSubject.next(user);
				}
				if(user.status=='pending'){
					localStorage.setItem('pre_token', user.token);
				}
				return user;
			}));
	}
	singleReq(type, value) {
		if(type=='email'){
			return this.http.post<any>(`${environment.apiUrl}signupge`, {email:value})
			.pipe(map(data => {
				console.log(data);
				if(data.status=='success'){
					localStorage.setItem('pre_token', data.token);
				}
				return data;
			}));
		}
		if(type=='social'){
			return this.http.post<any>(`${environment.apiUrl}gGsignup`, value)
			.pipe(map(data => {
				if(data.status=='success'){
					localStorage.setItem('pre_token', data.token);
				}
				return data;
			}));
		}
		if(type=='email_code'){
			return this.http.post<any>(`${environment.apiUrl}signupgcone`, {code:value, token: localStorage.getItem('pre_token')});
		}
		if(type=='email_resend'){
			return this.http.post<any>(`${environment.apiUrl}signuprec`, {token: localStorage.getItem('pre_token')});
		}
		if(type=='email_change'){
			return this.http.post<any>(`${environment.apiUrl}signupgce`, {email:value, token: localStorage.getItem('pre_token')});
		}
		if(type=='password')
			return this.http.post<any>(`${environment.apiUrl}signupgpwd`, {password:value, token: localStorage.getItem('pre_token')});
		if(type=='phone'){
			return this.http.post<any>(`${environment.apiUrl}signupgp`, {phone:value.internationalNumber, countryISO:value.countryCode, token: localStorage.getItem('pre_token')});
		}
		if(type=='phone_code'){
			return this.http.post<any>(`${environment.apiUrl}signupgconp`, {code:value, token: localStorage.getItem('pre_token')})
			.pipe(map(user => {
				const expirationDate = new Date(new Date().getTime() + 60*60*1000).getTime().toString();
				if(user.status=='success'){
					localStorage.setItem('currentUser', JSON.stringify(user.userdata));
					localStorage.setItem('user_token', user.token);
					localStorage.setItem('temp_user', "true");
					localStorage.setItem('expirationDate', expirationDate);
					this.currentUserSubject.next(user);
				}
				return user;
			}));
		}
		if(type=='phone_recend')
			return this.http.post<any>(`${environment.apiUrl}signuprpc`, {token: localStorage.getItem('pre_token')});
	}
	clientVerify(type, codeE, codeP){
		if(type=='both')
			return this.http.post<any>(`${environment.apiUrl}signupcc`, {codeE, codeP, token: localStorage.getItem('pre_token')})
			.pipe(map(user => {
				const expirationDate = new Date(new Date().getTime() + 60*60*1000).getTime().toString();
				if(user.status=='success'){
					localStorage.setItem('currentUser', JSON.stringify(user.userdata));
					localStorage.setItem('user_token', user.token);
					localStorage.setItem('expirationDate', expirationDate);
					this.currentUserSubject.next(user);
				}
				return user;
			}));
		if(type=='phone')
			return this.http.post<any>(`${environment.apiUrl}signuprpc`, {token: localStorage.getItem('pre_token')});
		if(type=='email')
			return this.http.post<any>(`${environment.apiUrl}signuprec`, {token: localStorage.getItem('pre_token')});
	}
	logout() {
		// remove user from local storage and set current user to null
		localStorage.removeItem('currentUser');
		localStorage.removeItem('expirationDate');
		localStorage.removeItem('user_token');
		localStorage.removeItem('reset_flag');
		localStorage.removeItem('temp_user');
		localStorage.removeItem('paid');
		this.currentUserSubject.next(null);
	}
	sendProviderProfileData(userdata){
		return this.http.post<any>(`${environment.apiUrl}signupgprofiledone`, {userdata, token: localStorage.getItem('pre_token')})
		.pipe(map(user => {
			const expirationDate = new Date(new Date().getTime() + 60*60*1000).getTime().toString();
			if(user.status=='success'){
				localStorage.setItem('currentUser', JSON.stringify(user.userdata));
				localStorage.setItem('user_token', user.token);
				localStorage.setItem('expirationDate', expirationDate);
				this.currentUserSubject.next(user);
			}
			return user;
		}));
	}
}