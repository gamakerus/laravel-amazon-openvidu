import { Component, OnInit } from '@angular/core';
import { MatBottomSheet, MatBottomSheetConfig } from "@angular/material/bottom-sheet";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { RejectComponent} from "../../caregiver/reject/reject.component";
import { ApiService } from '../../services/api.service';
declare var $: any;
@Component({
	selector: 'app-interviews',
	templateUrl: './interviews.component.html',
	styleUrls: ['./interviews.component.scss']
})
export class InterviewsComponent implements OnInit {
	filePath= ''
	interviews = []
	weekName = []
	activeItem = null
	loading = false
	constructor(
		private _bottomSheet:MatDialog,
		private apiservice: ApiService,
	) {
		this.filePath = apiservice.env.downUrl
	}

	ngOnInit(): void {
		this.weekName = this.apiservice.weekName
		this.apiservice.getProviderInterviews().subscribe(
			data=>{
				if(data.status=='success'){
					this.interviews = data.interviewlist
					for(let i=0; i<this.interviews.length;i++){
						if(this.interviews[i].licensename)
							this.interviews[i].licensename = this.interviews[i].licensename.split("<||>")
						if(this.interviews[i].licenseimg)
							this.interviews[i].licenseimg = this.interviews[i].licenseimg.split("<||>")
					}
				}
			},
			error => {

			}
		)
	}
	cancelInterview(id, target){
		const dialogConfig = new MatDialogConfig();
		dialogConfig.data = {target:'interview', jobId:id}
		const bottomSheetRef = this._bottomSheet.open(RejectComponent, dialogConfig);
		bottomSheetRef.afterClosed().subscribe(data => {
			if(data)
				$(target).addClass('rejected')
		});
	}
	acceptInterview(id){
		this.activeItem = id
		this.loading = true
		this.apiservice.acceptInterview(id).subscribe(
			data=>{
				this.loading = false
				if(data.status=='success'){
					for(let i=0;i<this.interviews.length;i++){
						if(this.interviews[i].intid==this.activeItem){
							this.interviews[i].status = 1
						}
					}
				}
			},
			error=>{
				this.loading = false
				console.log(error)
			}
		)
	}
}
