import { Component, OnInit, Input } from '@angular/core';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.scss']
})
export class DetailComponent implements OnInit {
  userData = null
  userId = null
  services = [
    'CareGiver',
    'Nursing',
    'Therapy'
  ]
  languages = []
  expertises = []
  licenses = []
  service_array = []
  weekname = []
  filePath = ''
  sub:any
  constructor(
    private apiservice: ApiService,
  ) {
    this.filePath = apiservice.env.downUrl
  }

  ngOnInit(): void {
    this.weekname = this.apiservice.weekName
    this.sub = this.apiservice.selectUserId.subscribe(
      id => {
        this.userId = id
        this.apiservice.getUserInfo(this.userId).subscribe(
          data => {
            console.log(data)
            this.userData = data.userdata
            let licName = this.userData.licensename;
            let licImg = this.userData.licenseimg;
            if(licName)
              this.userData.licensename = licName.split("<||>")
            if(licImg)
              this.userData.licenseimg = licImg.split("<||>")
            this.apiservice.getMisData(this.userData.service).subscribe(
              data => {
                for(let lang of data.language){
                  this.languages[lang.id] = lang.name
                }
                for(let exp of data.exspec){
                  this.expertises[exp.id] = exp.name
                }
                for(let ser of data.service){
                  this.service_array[ser.id] = ser.name
                }
              },
              error => {
                console.log(error)
              }
            )
          },
          error =>{
            console.log(error)
          }
        )
      }
    )
  }
  ngOnDestroy(){
    if(this.sub)
      this.sub.unsubscribe();
  }
}
