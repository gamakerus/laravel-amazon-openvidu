import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { FlexdlgComponent } from '../../layout/flexdlg/flexdlg.component'
import { ActivatedRoute } from '@angular/router';

@Component({
	selector: 'app-transactions',
	templateUrl: './transactions.component.html',
	styleUrls: ['./transactions.component.scss']
})
export class TransactionsComponent implements OnInit {
	stripeUrl = ''
	registerFlag = null
	paymentType = null
	last4 = null
	status = 0
	trans = []
	page = 1
	maxpage = 1
	constructor(
		private apiservice: ApiService,
		private dialog:MatDialog,
		private route: ActivatedRoute,
	) { }

	ngOnInit(): void {
		this.apiservice.getPaymentStatus().subscribe(
			data=>{
				console.log(data)
				if(data.status=='success'){
					this.registerFlag = data.result.existed==1?true:false
					this.paymentType = data.result.type
					this.last4 = data.result.last4
					this.status = data.result.status
				}
			}
		)
		this.route.params.subscribe(params => {
			if(params['page'])
				this.page = parseInt(params['page']);
			
			this.apiservice.getProviderTransaction(this.page).subscribe(
				data=>{
					if(data.status=='success'){
						this.maxpage = data.totalpage
						this.trans = data.translist
					}
				}
			)
		});
	}
	setPayment(){
		this.apiservice.setPayment().subscribe(
			data=>{
				if(data.status=='success'){
					this.stripeUrl = data.url
					window.location.href = data.url
				}
			}
		)
	}
	viewService(id){
		const dialogConfig = new MatDialogConfig();
		dialogConfig.autoFocus = true;
		dialogConfig.data = {target:'service4pay', data:{service:this.trans[id].service, subservice:this.trans[id].servicename}}
		this.dialog.open(FlexdlgComponent, dialogConfig);
	}
}
