import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from  '@angular/material/dialog';
import { ApiService } from '../../services/api.service';
@Component({
	selector: 'app-reject',
	templateUrl: './reject.component.html',
	styleUrls: ['./reject.component.scss']
})
export class RejectComponent implements OnInit {
	reasons = null
	other_desc = ''
	reason_arr = []
	loading = false
	user = null
	constructor(
		private rejectRef:MatDialogRef<RejectComponent>,
		private apiservice: ApiService,
		@Inject(MAT_DIALOG_DATA) public data:any
	) { 
		
	}

	ngOnInit(): void {
		this.user = JSON.parse(localStorage.getItem('currentUser'));
		if(this.data.target && this.data.target=='interview'){
			this.apiservice.getRejectReason4Interview().subscribe(
				data=>{
					if(data.status=='success'){
						this.reason_arr = data.reason
					}
				}
			)
		}else{
			this.apiservice.getRejectReason().subscribe(
				data=>{
					if(data.status=='success'){
						this.reason_arr = data.reason
					}
				}
			)
		}
	}
	closeDlg(){
		this.rejectRef.close(null);
	}
	cancelJob(){
		this.loading=true
		let data = {
			jobid:this.data.jobId,
			reason:this.reasons,
			other_desc:this.other_desc
		}

		this.apiservice.setRejectReason(data, this.data.target).subscribe(
			data=>{
				this.loading=false
				if(data.status=='success')
					this.rejectRef.close(this.reasons);
			},
			error=>{
				console.log(error)
				this.loading=false
			}
		)

	}
}
