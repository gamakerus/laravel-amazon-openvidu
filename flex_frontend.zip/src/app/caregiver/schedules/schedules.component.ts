import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';
declare var $: any;
@Component({
	selector: 'app-schedules',
	templateUrl: './schedules.component.html',
	styleUrls: ['./schedules.component.scss']
})
export class SchedulesComponent implements OnInit {
	weekName = []
	live_in = false
	successFlag = false
	loading = false
	userdataErr = {
		service_time:0,
		interview_time:0,
		other:0
	}
	serviceTime = [
		{
			name:0,
			checked:false,
			start:0,
			end:0
		},{
			name:1,
			checked:false,
			start:0,
			end:0
		},{
			name:2,
			checked:false,
			start:0,
			end:0
		 },{
			name:3,
			checked:false,
			start:0,
			end:0
		},{
			name:4,
			checked:false,
			start:0,
			end:0
		},{
			name:5,
			checked:false,
			start:0,
			end:0
		},{
			name:6,
			checked:false,
			start:0,
			end:0
		}
	]
	interviewTime = [
		{
			name:0,
			checked:false,
			start:0,
			end:0
		},{
			name:1,
			checked:false,
			start:0,
			end:0
		},{
			name:2,
			checked:false,
			start:0,
			end:0
		 },{
			name:3,
			checked:false,
			start:0,
			end:0
		},{
			name:4,
			checked:false,
			start:0,
			end:0
		},{
			name:5,
			checked:false,
			start:0,
			end:0
		},{
			name:6,
			checked:false,
			start:0,
			end:0
		}
	]
	failed = false
	startIndex = 0
	endIndex = 0
	currentUser = null
	constructor(
		private apiservice: ApiService,
	) { }

	ngOnInit(): void {
		this.weekName = this.apiservice.weekName
		this.apiservice.getSchedule().subscribe(
			data=>{
				if(data.status=='success'){
					for(let i=0;i<data.sschedule.length;i++){
						this.serviceTime[parseInt(data.sschedule[i].week)].checked = true
					}
					this.serviceTime[0].start = parseInt(data.sschedule[0].start)
					this.serviceTime[0].end = parseInt(data.sschedule[0].end)
					this.live_in = data.live_in
					for(let i=0;i<data.ischedule.length;i++){
						this.interviewTime[parseInt(data.ischedule[i].week)].checked = true
						this.interviewTime[parseInt(data.ischedule[i].week)].start = data.ischedule[i].start
						this.interviewTime[parseInt(data.ischedule[i].week)].end = data.ischedule[i].end
					}
				}
			},
			error=>{
				console.log(error)
			}
		)
	}
	setSchedule(){
		this.successFlag = false
		this.failed = false
		let edited = false
		for(let i=0;i<this.serviceTime.length;i++){
			edited = edited || this.serviceTime[i].checked
		}
		if(!edited){
			this.userdataErr.service_time=1
			this.failed = true
			return false
		}
		edited = false
		for(let i=0;i<this.interviewTime.length;i++){
			edited = edited || this.interviewTime[i].checked
		}
		if(!edited){
			this.userdataErr.interview_time=1
			this.failed = true
			return false
		}
		this.loading = true
		let s_data = {
			sschedule:this.serviceTime,
			ischedule:this.interviewTime,
			live_in:this.live_in
		}
		this.apiservice.setSchedule(s_data).subscribe(
			data=>{
				this.loading = false
				if(data.status=='success'){
					this.successFlag = true
				} else {
					this.userdataErr.other = 1
					this.failed = true
				}
			},
			error=>{
				this.loading = false
				this.userdataErr.other = 1
				this.failed = true
			}
		)
	}
	openTimeSetting(event, data){
		$('.time-setting').fadeOut()
		if(data.checked)
			$(event).parents('.form-group').find('.time-setting').fadeIn()
	}
	closeTimePanel(data:any){
		$('.time-setting').fadeOut()
	}
}
