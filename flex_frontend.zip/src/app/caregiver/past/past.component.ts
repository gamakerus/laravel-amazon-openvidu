import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { ActivatedRoute } from '@angular/router';
declare var $: any;
@Component({
	selector: 'app-past',
	templateUrl: './past.component.html',
	styleUrls: ['./past.component.scss']
})
export class PastComponent implements OnInit {
	filePath = ''
	services = []
	activeJobId = null
	services_name = [
    'CareGiver',
    'Nursing',
    'Therapy'
	]
	page = 1
	maxpage = 1
	constructor(
		private apiservice: ApiService,
		private route: ActivatedRoute,
	) {
		this.filePath = apiservice.env.downUrl
	}

	ngOnInit(): void {
		this.route.params.subscribe(params => {
			if(params['page'])
				this.page = parseInt(params['page']);
			this.apiservice.getFinishedJobs(this.page).subscribe(
				data =>{
					if(data.status=='success'){
						this.maxpage = data.totalpage
						this.services = data.previousjob
					}
				}
			)
		});
	}
	viewDetail(id, sidebar){
		this.activeJobId = id
		this.apiservice.selectJob(id);
		sidebar.toggle()
	}
}
