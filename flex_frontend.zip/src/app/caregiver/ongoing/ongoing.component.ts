import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { RejectComponent} from "../reject/reject.component";
import { ApiService } from '../../services/api.service';
declare var $: any;
@Component({
	selector: 'app-ongoing',
	templateUrl: './ongoing.component.html',
	styleUrls: ['./ongoing.component.scss']
})
export class OngoingComponent implements OnInit {
	filePath = ''
	services = []
	activeJobId = null
	services_name = [
    'CareGiver',
    'Nursing',
    'Therapy'
	]
	constructor(
		private _bottomSheet:MatDialog,
		private apiservice: ApiService,
	) {
		this.filePath = apiservice.env.downUrl
	}

	ngOnInit(): void {
		this.apiservice.getOngoingJobs().subscribe(
			data =>{
				if(data.status=='success'){
					this.services = data.ongoingjob
				}
			}
		)
	}
	cancelService(jobId, target){
		const dialogConfig = new MatDialogConfig();
		dialogConfig.data = {target:'job', jobId}
		const bottomSheetRef = this._bottomSheet.open(RejectComponent, dialogConfig);
		bottomSheetRef.afterClosed().subscribe(data => {
			if(data)
				$(target).addClass('rejected')
		});
	}
	viewDetail(id, sidebar){
		this.activeJobId = id
		this.apiservice.selectJob(id);
		sidebar.toggle()
	}
}
