import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';
@Component({
	selector: 'app-services',
	templateUrl: './services.component.html',
	styleUrls: ['./services.component.scss']
})
export class ServicesComponent implements OnInit {
	service = 1
	language = []
	expertises = []
	licenses = []
	loading = false
	userdata = {
		language:[],
		expertise:[],
		license:[]
	}
	userdataErr = {
		language:0,
		expertise:0,
		license:0
	}
	price = 0;
	failed = false
	success = false
	editFlag = false
	constructor(
		private apiservice: ApiService,
	) { }

	ngOnInit(): void {
		this.apiservice.getUserProfileData().subscribe(
			data=>{
				console.log(data)
				this.service = data.userdata.service.toString()
				this.userdata.language = data.userdata.language
				this.userdata.license = data.userdata.license
				this.userdata.expertise = data.userdata.exspec
				this.price = data.userdata.price
			},
			error =>{
				console.log(error)
			}
		)
		this.apiservice.getMisData(1).subscribe(
			data => {
				this.language = data.language
				this.expertises = data.exspec
				this.licenses = data.license
			},
			error => {
				console.log(error)
			}
		)
	}
	updateData(){
		this.failed =false
		this.success = false
		this.userdataErr = {
			language:0,
			expertise:0,
			license:0
		}
		if(this.userdata.language.length==0){
			this.userdataErr.language=1
			this.failed = true
			return false
		}
		if(this.userdata.expertise.length==0){
			this.userdataErr.expertise=1
			this.failed = true
			return false
		}
		if(this.userdata.license.length==0){
			this.userdataErr.license=1
			this.failed = true
			return false
		}
		this.loading = true
		this.apiservice.updateQualification(this.userdata).subscribe(
			data=>{
				this.loading = false
				if(data.status=='success'){
					this.success = true
				}
				console.log(data)
			},
			error => {
				this.loading = false
				console.log(error)
			}
		)
	}
	setEditState(){
		this.editFlag = ! this.editFlag
	}
	updatePrice(){
		this.apiservice.updatePrice(this.price).subscribe(
			data=>{
				this.editFlag = ! this.editFlag
			},
			error => {
				this.editFlag = ! this.editFlag
				console.log(error)
			}
		)
	}
}
