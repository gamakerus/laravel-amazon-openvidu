import { Component, OnInit } from '@angular/core';
import { NativeDateAdapter, DateAdapter,	MAT_DATE_FORMATS } from '@angular/material/core';
import { formatDate } from '@angular/common';
import { MatDialog, MatDialogConfig } from  '@angular/material/dialog';
import { ImageEditerComponent} from "../../layout/image-editer/image-editer.component";
import { ApiService } from '../../services/api.service';
import { AuthenticationService } from '../../services/authentication.service';

declare var $: any;
export const PICK_FORMATS = {
	parse: {dateInput: {month: 'short', year: 'numeric', day: 'numeric'}},
	display: {
		dateInput: 'input',
		monthYearLabel: {year: 'numeric', month: 'short'},
		dateA11yLabel: {year: 'numeric', month: 'long', day: 'numeric'},
		monthYearA11yLabel: {year: 'numeric', month: 'long'}
	}
};

class PickDateAdapter extends NativeDateAdapter {
	format(date: Date, displayFormat: Object): string {
		if (displayFormat === 'input') {
			return formatDate(date,'MM/dd/yyyy',this.locale);;
		} else {
			return date.toDateString();
		}
	}
}
@Component({
	selector: 'app-profile',
	templateUrl: './profile.component.html',
	styleUrls: ['./profile.component.scss'],
	providers: [
		{provide: DateAdapter, useClass: PickDateAdapter},
		{provide: MAT_DATE_FORMATS, useValue: PICK_FORMATS}
	]
})
export class ProfileComponent implements OnInit {
	croppedImage: any = '';
	userdata = {
		firstname:'', 
		lastname:'',
		avatar:null,
		gender:false,
		address:'',
		birthday:null,
		hiremethod:0,
		service:0,
		language:[],
		expertise:[],
		license:[],
		activities:[],
		service_time:[],
		interview_time:[],
		latitude:0,
		longitude:0,
		live_in:0,
	}
	userdataErr = {
		firstname:0, 
		lastname:0,
		address:0,
		birthday:0,
		hiremethod:0,
		service:0,
		language:0,
		expertise:0,
		license:0,
		activities:0,
		service_time:0,
		interview_time:0,
		latitude:0,
		longitude:0,
		mis:0
	}
	language = []
	expertises = []
	licenses = []
	license_name = {}
	activities = []
	step = 1
	weekName = []
	serviceTime = [
		{
			name:0,
			checked:false,
			start:0,
			end:0
		},{
			name:1,
			checked:false,
			start:0,
			end:0
		},{
			name:2,
			checked:false,
			start:0,
			end:0
		 },{
			name:3,
			checked:false,
			start:0,
			end:0
		},{
			name:4,
			checked:false,
			start:0,
			end:0
		},{
			name:5,
			checked:false,
			start:0,
			end:0
		},{
			name:6,
			checked:false,
			start:0,
			end:0
		}
	]
	interviewTime = [
		{
			name:0,
			checked:false,
			start:0,
			end:0
		},{
			name:1,
			checked:false,
			start:0,
			end:0
		},{
			name:2,
			checked:false,
			start:0,
			end:0
		 },{
			name:3,
			checked:false,
			start:0,
			end:0
		},{
			name:4,
			checked:false,
			start:0,
			end:0
		},{
			name:5,
			checked:false,
			start:0,
			end:0
		},{
			name:6,
			checked:false,
			start:0,
			end:0
		}
	]
	failed = false
	startIndex = 0
	endIndex = 0
	currentUser = null
	filePath = ''
	fileToUpload = {};

	constructor(
		private dialog:MatDialog,
		private apiservice: ApiService,
		private authenticationService: AuthenticationService,
	) {
		this.filePath = apiservice.env.downUrl
	}
	handleFileInput(files: FileList, id, filename) {
		// $(filename).text(files.item(0).name)
		this.fileToUpload[id] = files.item(0);
	}
	saveLicense(){
		this.failed = false
		let files = []
		for(let i=0;i<this.userdata.license.length;i++){
			let id = this.userdata.license[i]
			if(! this.fileToUpload[id]){
				this.userdataErr.license=2
				this.failed = true
				return false
			}
			files.push({id, file:this.fileToUpload[id]})
		}
		this.apiservice.postFile(files).subscribe(
			data=>{
				console.log(data)
			}
		)
		this.nextStep()
	}
	changeLic(){
		console.log(this.fileToUpload)
		for(let id in this.fileToUpload){
			let flag = false
			for(let l_id of this.userdata.license){
				if(parseInt(id)==parseInt(l_id)){
					flag = true
					break;
				}
			}
			if(!flag){
				this.fileToUpload[id] = null
			}
		}
	}
	setCurrentLocation() {
		if ('geolocation' in navigator) {
			navigator.geolocation.getCurrentPosition((position) => {
				this.userdata.latitude = position.coords.latitude;
				this.userdata.longitude = position.coords.longitude;
				
				this.apiservice.getAddress(position.coords.latitude, position.coords.longitude).subscribe(
					data => {
						this.userdata.address = data.results[0].formatted_address
					},
					error => {
						console.log(error)
					}
				)
			});
		}
	}
	ngOnInit(): void {
		this.weekName = this.apiservice.weekName
		let payedFlag = localStorage.getItem('paid');
		if(payedFlag){
			if(payedFlag=='not')
				this.step = 5
			if(payedFlag=='paid')
				this.step = 6
		}
		this.currentUser = localStorage.getItem('currentUser')
		if(this.currentUser){
			this.currentUser = JSON.parse(this.currentUser)
			if(this.currentUser.fname!=null && this.currentUser.fname!=''){
				this.userdata.firstname = this.currentUser.fname
			}
			if(this.currentUser.lname!=null && this.currentUser.lname!=''){
				this.userdata.lastname = this.currentUser.lname
			}
			if(this.currentUser.avatar!=null && this.currentUser.avatar!=''){
				this.croppedImage = "uploads/" + this.currentUser.avatar
			}
		}
		this.apiservice.getDescription('hire').subscribe(
			data=>{
				if(data.status=='success'){
					console.log(data.desc)
					$($(".flex-help")[0]).data('content', data.desc[0]['subtype']==1?data.desc[0]['name']:data.desc[1]['name'])
					$($(".flex-help")[1]).data('content', data.desc[1]['subtype']==1?data.desc[0]['name']:data.desc[1]['name'])
					$(".flex-help").popover()
				}
			}
		)
	}
	fileChangeEvent(event: any): void {
		this.imageEditerShow(event);
		
	}
	triggerUpload(){
		$("#avatar-upload").click()
	}
	imageEditerShow(event) {
		let dialogConfig = new MatDialogConfig();
		dialogConfig['data'] = {event:event, croppedImage:this.croppedImage}
		// dialogConfig.autoFocus = true;
		const dialogRef = this.dialog.open(ImageEditerComponent, dialogConfig);
		dialogRef.afterClosed().subscribe(result => {
			if(result){
				this.croppedImage = result;
				this.userdata.avatar = result;
				// this.formdata.avatar = result;
			}
			$("#avatar-upload").val('')
		});
	}
	showTimePanel(){
		
	}
	nextStep(){
		this.failed = false
		this.userdataErr = {
			firstname:0, 
			lastname:0,
			address:0,
			birthday:0,
			hiremethod:0,
			service:0,
			language:0,
			expertise:0,
			license:0,
			activities:0,
			service_time:0,
			interview_time:0,
			latitude:0,
			longitude:0,
			mis:0
		}
		if(this.step==1){
			if(this.userdata.firstname==''){
				this.userdataErr.firstname=1
				this.failed = true
				return false
			}
			if(this.userdata.lastname==''){
				this.userdataErr.lastname=1
				this.failed = true
				return false
			}
			if(this.userdata.address==''){
				this.userdataErr.address=1
				this.failed = true
				return false
			}
			if(this.userdata.birthday=='' || this.userdata.birthday==null){
				this.userdataErr.birthday=1
				this.failed = true
				return false
			}
			if(this.userdata.hiremethod==0){
				this.userdataErr.hiremethod=1
				this.failed = true
				return false
			}
			if(this.userdata.service==0){
				this.userdataErr.service=1
				this.failed = true
				return false
			}
			this.apiservice.getMisData(this.userdata.service).subscribe(
				data => {
					this.language = data.language
					this.expertises = data.exspec
					this.licenses = data.license
					for(let j=0; j<this.licenses.length; j++){
						this.license_name[this.licenses[j].id] = this.licenses[j].name
					}
					this.activities = data.service
					this.step++
				},
				error => {
					this.failed = true
					this.userdataErr.mis = 1
					return false
				}
			)
			return true
		}
		if(this.step==2){
			if(this.userdata.language.length==0){
				this.userdataErr.language=1
				this.failed = true
				return false
			}
			if(this.userdata.expertise.length==0){
				this.userdataErr.expertise=1
				this.failed = true
				return false
			}
			if(this.userdata.license.length==0){
				this.userdataErr.license=1
				this.failed = true
				return false
			}
			if(this.userdata.activities.length==0){
				this.userdataErr.activities=1
				this.failed = true
				return false
			}
		}
		
		this.step++
	}
	prevStep(){
		this.step--
	}
	nextPage(){
		if(this.currentUser.payflag==1){
			this.step = this.step+2
		}else{
			this.step++
		}
	}
	prevPage(){
		if(this.currentUser.payflag==1){
			this.step = this.step-2
		}else{
			this.step--
		}
	}
	openTimeSetting(event, data){
		$('.time-setting').fadeOut()
		if(data.checked)
			$(event).parents('.form-group').find('.time-setting').fadeIn()
	}
	closeTimePanel(data:any){
		$('.time-setting').fadeOut()
	}
	submitData(){
		let edited = false
		for(let i=0;i<this.serviceTime.length;i++){
			edited = edited || this.serviceTime[i].checked
		}
		if(!edited){
			this.userdataErr.service_time=1
			this.failed = true
			return false
		}
		edited = false
		for(let i=0;i<this.interviewTime.length;i++){
			edited = edited || this.interviewTime[i].checked
		}
		if(!edited){
			this.userdataErr.interview_time=1
			this.failed = true
			return false
		}
		this.userdata.service_time = this.serviceTime
		this.userdata.interview_time = this.interviewTime

		this.userdata.birthday = this.userdata.birthday.toDateString()
		this.authenticationService.sendProviderProfileData(this.userdata).subscribe(
			data => {
				this.step++
			},
			error => {
				this.failed = true
				this.userdataErr.mis = 1
				return false
			}
		)
	}
	finishProfile(){
		this.authenticationService.logout()
		window.location.href = ""
	}
	getAddress(place: object) { 
		this.userdata.latitude = place['geometry']['location'].lat()
		this.userdata.longitude = place['geometry']['location'].lng()
		this.userdata.address = place['formatted_address']
	}
	goLastPage($event){
		this.failed = false
		localStorage.setItem('paid','paid');
		if($event){
			this.step++
		} else {
			this.failed = true
			this.userdataErr.mis = 4
		}
	}
	selectLiveIn(){
		if(this.userdata.live_in){
			this.serviceTime[0].start = 0
			this.serviceTime[0].end = 23
		} else {
			this.serviceTime[0].start = 0
			this.serviceTime[0].end = 0
		}
	}
}
