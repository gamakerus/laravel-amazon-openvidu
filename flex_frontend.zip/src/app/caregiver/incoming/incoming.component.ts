import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { RejectComponent} from "../reject/reject.component";
import { ApiService } from '../../services/api.service';
declare var $: any;
@Component({
	selector: 'app-incoming',
	templateUrl: './incoming.component.html',
	styleUrls: ['./incoming.component.scss']
})
export class IncomingComponent implements OnInit {
	filePath = ''
	services = []
	activeJobId = null
	services_name = [
    'CareGiver',
    'Nursing',
    'Therapy'
	]
	loading = false
	constructor(
		private _bottomSheet:MatDialog,
		private apiservice: ApiService,
	) {
		this.filePath = apiservice.env.downUrl
	}

	ngOnInit(): void {
		this.apiservice.getIncomingJobs().subscribe(
			data =>{
				if(data.status=='success'){
					this.services = data.incomingjob
				}
			}
		)
	}
	cancelService(jobId, target){
		const dialogConfig = new MatDialogConfig();
		dialogConfig.data = {target:'job', jobId}
		const bottomSheetRef = this._bottomSheet.open(RejectComponent, dialogConfig);
		bottomSheetRef.afterClosed().subscribe(data => {
			if(data)
				$(target).addClass('rejected')
		});
	}
	viewDetail(id, sidebar){
		this.activeJobId = id
		this.apiservice.selectJob(id);
		sidebar.toggle()
	}
	acceptJob(jobId, target){
		this.loading = true
		this.apiservice.acceptJob(jobId).subscribe(
			data=>{
				this.loading = false
				if(data.status=='success'){
					$(target).addClass('rejected')
				}
			},
			error=>{
				this.loading = false
				console.log(error)
			}
		)
	}
}
