import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { RejectComponent} from "../../caregiver/reject/reject.component";
import { ApiService } from '../../services/api.service';
declare var $: any;
@Component({
	selector: 'app-incoming',
	templateUrl: './incoming.component.html',
	styleUrls: ['./incoming.component.scss']
})
export class IncomingclientComponent implements OnInit {
	filePath = ''
	services = []
	activeJobId = null
	constructor(
		private _bottomSheet:MatDialog,
		private apiservice: ApiService,
	) {
		this.filePath = apiservice.env.downUrl
	}

	ngOnInit(): void {
		this.apiservice.getIncomingServices().subscribe(
			data =>{
				if(data.status=='success'){
					this.services = data.incominglist
					for(let i=0; i<this.services.length;i++){
						if(this.services[i].licensename)
							this.services[i].licensename = this.services[i].licensename.split("<||>")
						if(this.services[i].licenseimg)
							this.services[i].licenseimg = this.services[i].licenseimg.split("<||>")
					}
				}
			}
		)
	}
	cancelService(jobId, target){
		const dialogConfig = new MatDialogConfig();
		dialogConfig.data = {target:'service', jobId}
		const bottomSheetRef = this._bottomSheet.open(RejectComponent, dialogConfig);
		bottomSheetRef.afterClosed().subscribe(data => {
			if(data)
				$(target).addClass('rejected')
		});
	}
	viewDetail(id, sidebar){
		this.activeJobId = id
		this.apiservice.selectJob(id);
		sidebar.toggle()
	}
	
}
