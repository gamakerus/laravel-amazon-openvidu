import { Component, OnInit, Input } from '@angular/core';
import { MatDialogRef } from  '@angular/material/dialog';
import { ApiService } from '../../services/api.service';
declare var $: any;
@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.scss']
})
export class BookingComponent implements OnInit {
  schedule = []
  weekName = []
  selected = null
  step =0
  errFlag = 0
  hour = 0
  loading =false
  @Input() userId:any
  constructor(
    private apiservice: ApiService,
    private dialogRef:MatDialogRef<BookingComponent>,
  ) { }

  ngOnInit(): void {
    this.weekName = this.apiservice.weekName
    this.apiservice.getInterviewSchedule(this.userId).subscribe(
			data => {
				this.schedule = data.interview
			},
			error=>{
				console.log(error)
			}
		)
  }
  confirmInterview($event){
    this.step = 2
    this.errFlag = 0
    if(!$event || this.selected==null){
      this.errFlag = 1
      return false
    }
    this.loading = true
    this.apiservice.setInterviewSchedule(this.selected, this.hour).subscribe(
			data => {
        this.loading = false
				if(data.status=='success'){
          this.step++;
          return
        }
        if(data.status=='exist'){
          this.errFlag = 2
          return
        }
			},
			error=>{
        this.loading = false
        this.errFlag = 3
				console.log(error)
			}
		)
  }
  nextstep(step){
    this.apiservice.checkInterviewSchedule(this.selected, this.hour).subscribe(
			data => {
        this.loading = false
				if(data.status=='success'){
          this.step = step
          return
        }
        if(data.status=='exist'){
          this.errFlag = 2
          return
        }
			},
			error=>{
        this.loading = false
        this.errFlag = 3
				console.log(error)
			}
		)
  }
  closeDlg(){
		this.dialogRef.close();
  }
  openTimeSetting(event, data){
    $('.time-setting').fadeOut()
		$(event).fadeIn()
	}
	closeTimePanel(data:any){
		$('.time-setting').fadeOut()
  }
  selectHour(hour){
    console.log(hour)
    this.hour = hour
  }
}
