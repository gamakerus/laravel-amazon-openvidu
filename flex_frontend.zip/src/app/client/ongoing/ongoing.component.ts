import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { FlexdlgComponent } from '../../layout/flexdlg/flexdlg.component'
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";

@Component({
	selector: 'app-ongoing',
	templateUrl: './ongoing.component.html',
	styleUrls: ['./ongoing.component.scss']
})
export class OngoingclientComponent implements OnInit {
	filePath = ''
	services = []
	activeJobId = null
	constructor(
		private apiservice: ApiService,
		private dialog:MatDialog,
	) {
		this.filePath = apiservice.env.downUrl
	}

	ngOnInit(): void {
		this.apiservice.getOngoingServices().subscribe(
			data =>{
				if(data.status=='success'){
					this.services = data.ongoinglist
					for(let i=0; i<this.services.length;i++){
						if(this.services[i].licensename)
							this.services[i].licensename = this.services[i].licensename.split("<||>")
						if(this.services[i].licenseimg)
							this.services[i].licenseimg = this.services[i].licenseimg.split("<||>")
					}
				}
			}
		)
	}
	viewDetail(id, sidebar){
    this.activeJobId = id
		this.apiservice.selectJob(id);
		sidebar.toggle()
  }
	hireProvider(userId){
		const dialogConfig = new MatDialogConfig();
		dialogConfig.autoFocus = true;
		dialogConfig.data = {target:'hire', userId}
		this.dialog.open(FlexdlgComponent, dialogConfig);
	}
	
}
