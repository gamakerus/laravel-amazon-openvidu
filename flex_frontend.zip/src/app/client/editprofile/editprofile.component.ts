
import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { NativeDateAdapter, DateAdapter,	MAT_DATE_FORMATS } from '@angular/material/core';
import { formatDate } from '@angular/common';
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { FlexdlgComponent } from '../../layout/flexdlg/flexdlg.component'
declare var $: any;

export const PICK_FORMATS = {
  parse: {dateInput: {month: 'short', year: 'numeric', day: 'numeric'}},
  display: {
    dateInput: 'input',
    monthYearLabel: {year: 'numeric', month: 'short'},
    dateA11yLabel: {year: 'numeric', month: 'long', day: 'numeric'},
    monthYearA11yLabel: {year: 'numeric', month: 'long'}
  }
};

class PickDateAdapter extends NativeDateAdapter {
  format(date: Date, displayFormat: Object): string {
    if (displayFormat === 'input') {
      return formatDate(date,'MM/dd/yyyy',this.locale);;
    } else {
      return date.toDateString();
    }
  }
}
@Component({
  selector: 'app-editprofile',
  templateUrl: './editprofile.component.html',
  styleUrls: ['./editprofile.component.scss'],
  providers: [
    {provide: DateAdapter, useClass: PickDateAdapter},
    {provide: MAT_DATE_FORMATS, useValue: PICK_FORMATS}
  ]
})
export class EditprofileclientComponent implements OnInit {
  userdata = {
    fname:'', 
    lname:'',
    gender:false,
    address:'',
    dob:null,
    lat:0,
    long:0,
  }
  userdataErr = {
    firstname:0, 
    lastname:0,
    email:0,
    password:0,
    phone:0,
    address:0,
    birthday:0,
    latitude:0,
    longitude:0,
    mis:0
  }
  email = ''
  phone = ''
  countryiso = ''
  password=''
  failed = false
  loading = false

  constructor(
    private apiservice: ApiService,
		private dialog:MatDialog,
  ) { }

  ngOnInit(): void {
		this.initData()
  }
	initData():void {
		this.apiservice.getUserProfileData().subscribe(
			data => {
				this.userdata.address = data.userdata.address
				this.userdata.lat = data.userdata.lat
				this.userdata.long = data.userdata.long
				this.userdata.fname = data.userdata.fname
				this.userdata.lname = data.userdata.lname
				this.userdata.dob = new Date(data.userdata.dob)
				this.userdata.gender = data.userdata.gender
				this.email = data.userdata.email
				this.phone = data.userdata.phone
				this.countryiso = data.userdata.countryISO
				// this.phoneForm.controls.phone.setValue(data.userdata.phone)
			},
			error => {

			}
		)
	}

  setCurrentLocation() {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition((position) => {
        this.userdata.lat = position.coords.latitude;
        this.userdata.long = position.coords.longitude;
        
        this.apiservice.getAddress(position.coords.latitude, position.coords.longitude).subscribe(
          data => {
            this.userdata.address = data.results[0].formatted_address
          },
          error => {
            console.log(error)
          }
        )
      });
    }
  }

  saveProfile(){
    this.loading = true
    this.apiservice.setUserPofileData(this.userdata).subscribe(
      data => {
        let cuser = JSON.parse(localStorage.getItem('currentUser'))
        cuser.lat = this.userdata.lat
        cuser.long = this.userdata.long
				cuser.address = this.userdata.address
        localStorage.setItem('currentUser', JSON.stringify(cuser))
        this.loading = false
      },
      error => {
        this.loading = false
      }
    )
  }
  cpData(target){
		const dialogConfig = new MatDialogConfig();
		dialogConfig.autoFocus = true;
		if(target=='phone')
			dialogConfig.data = {target, phone:this.phone, countryISO:this.countryiso}
		else
			dialogConfig.data = {target}
		this.dialog.open(FlexdlgComponent, dialogConfig);
		this.apiservice.flexDlgClose.subscribe(
			data => {
				if(data=='email' || data=='phone'){
					this.initData()
				}
			}
		)
  }
  getAddress(place: object) { 
		this.userdata.lat = place['geometry']['location'].lat()
		this.userdata.long = place['geometry']['location'].lng()
		this.userdata.address = place['formatted_address']
	}
}
