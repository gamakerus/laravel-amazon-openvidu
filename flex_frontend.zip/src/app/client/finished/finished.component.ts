import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { FlexdlgComponent } from '../../layout/flexdlg/flexdlg.component'
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { ActivatedRoute } from '@angular/router';

@Component({
	selector: 'app-finished',
	templateUrl: './finished.component.html',
	styleUrls: ['./finished.component.scss']
})
export class FinishedComponent implements OnInit {
	filePath = ''
	services = []
	activeJobId = null
	page = 1
	maxpage = 1
	constructor(
		private apiservice: ApiService,
		private dialog:MatDialog,
		private route: ActivatedRoute,
	) {
		this.filePath = apiservice.env.downUrl
	}

	ngOnInit(): void {
		this.route.params.subscribe(params => {
			if(params['page'])
				this.page = parseInt(params['page']);

			this.apiservice.getFinishedServices(this.page).subscribe(
				data =>{
					if(data.status=='success'){
						this.services = data.finishedlist
						this.maxpage = data.totalpage
						for(let i=0; i<this.services.length;i++){
							if(this.services[i].licensename)
								this.services[i].licensename = this.services[i].licensename.split("<||>")
							if(this.services[i].licenseimg)
								this.services[i].licenseimg = this.services[i].licenseimg.split("<||>")
						}
					}
				}
			)
		});
		
	}
	viewDetail(id, sidebar){
    this.activeJobId = id
		this.apiservice.selectJob(id);
		sidebar.toggle()
  }
	hireProvider(userId){
		const dialogConfig = new MatDialogConfig();
		dialogConfig.autoFocus = true;
		dialogConfig.data = {target:'hire', userId}
		this.dialog.open(FlexdlgComponent, dialogConfig);
	}
	ratingView(jobId){
		const dialogConfig = new MatDialogConfig();
		dialogConfig.autoFocus = true;

		dialogConfig.data = {target:'rating', jobId}
		let dialogRef = this.dialog.open(FlexdlgComponent, dialogConfig);
		dialogRef.afterClosed().subscribe(
			data => {
				if(data && data.length==3){
					for(let i=0;i<this.services.length;i++){
						if(this.services[i].jobid==jobId){
							this.services[i].reviewflag = 1
							this.services[i].rate = data[0]
							this.services[i].review = data[1]
							break
						}
					}
				}
			}
		)
  }
}
