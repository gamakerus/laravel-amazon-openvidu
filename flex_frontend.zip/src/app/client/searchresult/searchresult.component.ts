import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { FlexdlgComponent } from '../../layout/flexdlg/flexdlg.component'
import { SearchfilterComponent} from "../../client/searchfilter/searchfilter.component";
import { ActivatedRoute } from '@angular/router';
@Component({
	selector: 'app-searchresult',
	templateUrl: './searchresult.component.html',
	styleUrls: ['./searchresult.component.scss']
})
export class SearchresultComponent implements OnInit {
	sorts = [
		{id:0, name:'Lowest Price'},
		{id:1, name:'Highest Price'},
		{id:2, name:'Most Reviews'},
		{id:3, name:'Fewest Reviews'},
		{id:4, name:'Proximity'},
	]
	filters = [
		{id:1, name:'Flexhealth'},
		{id:2, name:'Direct hire'},
		{id:0, name:'Both'},
	]
	search = {
		address:'',
		service:0,
		language:[],
		expertise:[],
		license:[],
		activities:[],
		selected_lang:[],
		selectedPerson:[],
		sort : 0,
		filter:0, 
		latitude:0,
		longitude:0,
		zipcode:null,
		other:'',
		otherActivityFlag :false,
		page:0
	}
	language = []
	expertises = []
	licenses = []
	activities = []
	searchdata = null
	providers = []
	family = []
	selected_user = null
	filePath = ''
	otherFlag = false;
	otherText = ''
	otherActivityFlag = false;
	page = 1
	maxpage = 1
	constructor(
		private apiservice: ApiService,
		private dialog:MatDialog,
		private route: ActivatedRoute,
	) {
		this.filePath = apiservice.env.downUrl
	}

	ngOnInit(): void {
		let searchdata = localStorage.getItem('searchFilter');
		if(searchdata){
			this.searchdata = JSON.parse(searchdata)
			this.search.address = this.searchdata.address
			this.search.service = this.searchdata.service
			this.search.language = this.searchdata.language
			this.search.expertise = this.searchdata.expertise
			this.search.license = this.searchdata.license
			this.search.activities = this.searchdata.activities
			this.search.selected_lang = this.searchdata.selected_lang
			this.search.selectedPerson = this.searchdata.selectedPerson.length==0?{id: 2, name: "Myself"}:this.searchdata.selectedPerson
			this.search.latitude = this.searchdata.latitude
			this.search.longitude = this.searchdata.longitude
			this.search.zipcode = this.searchdata.zipcode
			this.search.other = this.searchdata.other
			this.changeService(false)
		}
		this.route.params.subscribe(params => {
			if(params['page'])
				this.page = parseInt(params['page']);
			this.getProviderList()
		});
	}
	setCurrentLocation() {
		if ('geolocation' in navigator) {
			navigator.geolocation.getCurrentPosition((position) => {
				this.search.latitude = position.coords.latitude;
				this.search.longitude = position.coords.longitude;
				this.apiservice.getAddress(position.coords.latitude, position.coords.longitude).subscribe(
					data => {
						this.search.address = data.results[0].formatted_address
						this.search.zipcode = data.results[0].address_components[6].long_name
					},
					error => {
						console.log(error)
					}
				)
			},
			error=>{
				console.log(error)
			});
		} else {
			return
		}
	}
	changeZipCode(){
		this.apiservice.getGeocode(this.search.zipcode).subscribe(
			data => {
				if(data.results.length>0){
					this.search.address = data.results[0].formatted_address
					this.search.latitude = data.results[0].geometry.location.lat
					this.search.longitude = data.results[0].geometry.location.lng
				}
			}
		)
	}
	getAddress(place: object) { 
		this.search.latitude = place['geometry']['location'].lat()
		this.search.longitude = place['geometry']['location'].lng()
		this.search.address = place['formatted_address']
	}
	getProviderList(){
		this.otherFlag = false
		this.search.page = this.page
		localStorage.setItem('searchFilter', JSON.stringify(this.search))
		this.apiservice.getProviderList(this.search).subscribe(
			data => {
				if(data.status=='success'){
					this.providers = data.result
					this.family = data.relation
					this.maxpage = data.totalpage
					for(let i=0; i<this.providers.length;i++){
						if(this.providers[i].licensename)
							this.providers[i].licensename = this.providers[i].licensename.split("<||>")
						if(this.providers[i].licenseimg)
							this.providers[i].licenseimg = this.providers[i].licenseimg.split("<||>")
					}
				}else if(data.status=='other'){
					this.otherFlag = true
					this.otherText = data.otherdesc
				}
				window.scroll(0, 0);
			},
			error => {
				console.log(error)
			}
		)
	}
	viewDetail(id, sidebar){
		this.apiservice.selectUser(id);
		sidebar.toggle()
	}
	hireProvider(userId){
		const dialogConfig = new MatDialogConfig();
		dialogConfig.autoFocus = true;
		dialogConfig.data = {target:'hire', userId}
		this.dialog.open(FlexdlgComponent, dialogConfig);
		
	}
	bookInterview(userId){
		const dialogConfig = new MatDialogConfig();
		dialogConfig.autoFocus = true;
		dialogConfig.data = {target:'booking', userId}
		this.dialog.open(FlexdlgComponent, dialogConfig);
		
	}
	getSchedule(userId){
		const dialogConfig = new MatDialogConfig();
		dialogConfig.autoFocus = true;
		dialogConfig.data = {target:'schedule', userId}
		this.dialog.open(FlexdlgComponent, dialogConfig);
	}
	findCareGiver() {
		const dialogConfig = new MatDialogConfig();
		dialogConfig.autoFocus = true;
		dialogConfig.data = {state:'loggedin'}
		this.dialog.open(SearchfilterComponent, dialogConfig);
	}
	changeService(flag) {
		if(flag)
			this.search.activities = []
		this.apiservice.getMisData(this.search.service).subscribe(
			data => {
				this.language = data.language
				this.expertises = data.exspec
				this.licenses = data.license

				this.activities = [{id:0, name:'Other'}]
				this.activities = this.activities.concat(data.service)
			},
			error => {
				return false
			}
		)
	}
	changeActivity(target){
		if(this.search.activities[this.search.activities.length-1]==0){
			this.search.activities = [0]
			this.search.otherActivityFlag = true
			target.close()
		} else {
			this.search.otherActivityFlag = false
			if(this.search.activities[0]==0){
				let acti = this.search.activities
				this.search.activities=[]
				for(let i of acti){
					if(i==0)
						continue
					this.search.activities.push(i)
				}
			}
		}
	}
}
