import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from  '@angular/material/dialog';
import { ApiService } from '../../services/api.service';
import { NativeDateAdapter, DateAdapter,	MAT_DATE_FORMATS } from '@angular/material/core';
import { formatDate } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
declare var $: any;
export const PICK_FORMATS = {
	parse: {dateInput: {month: 'short', year: 'numeric', day: 'numeric'}},
	display: {
		dateInput: 'input',
		monthYearLabel: {year: 'numeric', month: 'short'},
		dateA11yLabel: {year: 'numeric', month: 'long', day: 'numeric'},
		monthYearA11yLabel: {year: 'numeric', month: 'long'}
	}
};

class PickDateAdapter extends NativeDateAdapter {
	format(date: Date, displayFormat: Object): string {
		if (displayFormat === 'input') {
			return formatDate(date,'MM/dd/yyyy',this.locale);;
		} else {
			return date.toDateString();
		}
	}
}
@Component({
	selector: 'app-searchfilter',
	templateUrl: './searchfilter.component.html',
	styleUrls: ['./searchfilter.component.scss'],
	providers: [
		{provide: DateAdapter, useClass: PickDateAdapter},
		{provide: MAT_DATE_FORMATS, useValue: PICK_FORMATS}
	]
})
export class SearchfilterComponent implements OnInit {
	step = 0
	service = 0
	language = []
	expertises = []
	licenses = []
	activities = []

	geoError = false
	userdata = {
		gender:false,
		address:'',
		scheduleType:"1",
		patient:"1",
		service:0,
		language:[],
		expertise:[],
		license:[],
		activities:[],
		service_time:null,
		interview_time:[],
		latitude:0,
		longitude:0,
		live_in:'',
		selected_lang:[],
		selectedPerson:[],
		selectedDay:null,
		selectedHour:null,
		startdate:null,
		zipcode:'',
		other:'',
		otherActivityFlag:false
	}
	family = []
	service_time = []
	daysperweek = []
	hoursperday = []
	weekName = []
	serviceTime = [
		{
			name:0,
			checked:false,
			start:0,
			end:0
		},{
			name:1,
			checked:false,
			start:0,
			end:0
		},{
			name:2,
			checked:false,
			start:0,
			end:0
		 },{
			name:3,
			checked:false,
			start:0,
			end:0
		},{
			name:4,
			checked:false,
			start:0,
			end:0
		},{
			name:5,
			checked:false,
			start:0,
			end:0
		},{
			name:6,
			checked:false,
			start:0,
			end:0
		}
	]
	subs = null
	errFlag = 0
	constructor(
		private route: ActivatedRoute,
		private router: Router,
		private apiservice: ApiService,
		private dialogRef:MatDialogRef<SearchfilterComponent>,
		@Inject(MAT_DIALOG_DATA) public data:any
	) {
		dialogRef.disableClose = true;
	}
	closeTimePanel(data:any){
		$('.time-setting').fadeOut()
	}
	setCurrentLocation() {
		this.errFlag = 0
		if ('geolocation' in navigator) {
			navigator.geolocation.getCurrentPosition((position) => {
				this.userdata.latitude = position.coords.latitude;
				this.userdata.longitude = position.coords.longitude;
				this.apiservice.getAddress(position.coords.latitude, position.coords.longitude).subscribe(
					data => {
						this.userdata.address = data.results[0].formatted_address
						this.userdata.zipcode = data.results[0].address_components[6].long_name
					},
					error => {
						console.log(error)
					}
				)
			},
			error=>{
				console.log(error)
				this.errFlag = 2
			});
		} else {
			this.errFlag = 2
			return
		}
	}
	ngOnInit(): void {
		this.weekName = this.apiservice.weekName
		this.subs = this.apiservice.loginEvent.subscribe(
			()=>{
				this.dialogRef.close();
			}
		)
	}
	ngOnDestroy(): void {
		if(this.subs)
			this.subs.unsubscribe()
	}
	closeDlg(){
		this.dialogRef.close();
	}
	nextstep(service){
		this.errFlag = 0
		if(this.step==1){
			if(this.userdata.address==''){
				this.errFlag = 1
				return false
			}
			if(this.userdata.latitude==0 && this.userdata.longitude==0){
				this.apiservice.getGeocode(this.userdata.zipcode).subscribe(
					data => {
						if(data.results.length>0){
							this.userdata.address = data.results[0].formatted_address
							this.userdata.latitude = data.results[0].geometry.location.lat
							this.userdata.longitude = data.results[0].geometry.location.lng
							this.apiservice.getProviderAround(this.userdata.latitude, this.userdata.longitude).subscribe(
								data =>{
									if(data.status=='success'){
										this.family = data.relation
										this.service_time = data.stime
										this.daysperweek = data.daytoweek
										this.hoursperday = data.timetoday
										this.step++
									}
									else{
										this.step = 21
										this.geoError = true
									}
								},
								error => {
									console.log(error)
									this.step = 21
									this.geoError = true
								}
							)
							
							return
						} else {
							this.step = 21
							this.geoError = true
							return
						}
					},
					error => {
						console.log(error)
					}
				)
			} else {
				this.apiservice.getProviderAround(this.userdata.latitude, this.userdata.longitude).subscribe(
					data =>{
						if(data.status=='success'){
							this.family = data.relation
							this.service_time = data.stime
							this.daysperweek = data.daytoweek
							this.hoursperday = data.timetoday
							this.step++
						}
						else{
							this.step = 21
							this.geoError = true
						}
					},
					error => {
						console.log(error)
						this.step = 21
						this.geoError = true
					}
				)
			}
		} else if(this.step==2){
			if(this.userdata.patient=="2" && this.userdata.selectedPerson.length==0){
				this.errFlag = 2
				return false;
			}
			if(this.userdata.selected_lang.length==0){
				this.errFlag = 3
				return false
			}
			this.step++
		} else if(this.step==3){
			if(this.userdata.activities.length==0){
				this.errFlag = 1
				return false;
			}
			if(this.userdata.license.length==0){
				this.errFlag = 2
				return false
			}
			if(this.userdata.expertise.length==0){
				this.errFlag = 3
				return false
			}

			localStorage.setItem('searchFilter', JSON.stringify(this.userdata));
			// this.apiservice.findprovider(this.userdata)
			if(this.data && this.data.state=='loggedin'){
				this.closeDlg()
			} else if(this.data && this.data.state=='loggedin_redirect'){
				this.closeDlg()
				this.router.navigate(['search/caregivers']);
			} else {
				this.step++
			}
		} else if(this.step==41){
			if(this.userdata.service_time=='' || this.userdata.service_time==null){
				this.errFlag = 1
				return false;
			}
			if(this.userdata.startdate==null){
				this.errFlag = 2
				return false
			}
			this.step++
		} else if(this.step==51){
			if(this.userdata.scheduleType=='1'){
				if(this.userdata.selectedDay==null){
					this.errFlag = 1
					return false;
				}
				if(this.userdata.selectedHour==null){
					this.errFlag = 2
					return false;
				}
			} else {
				let edited = false
				for(let i=0;i<this.serviceTime.length;i++){
					edited = edited || this.serviceTime[i].checked
				}
				if(!edited){
					this.errFlag = 3
					return false
				}
			}
			// localStorage.setItem('searchFilter', JSON.stringify(this.userdata));
			this.step++
		} else {
			this.step++
		}
		
		if(service){
			this.service = service
			this.userdata.service = service
			this.apiservice.getMisData(this.service).subscribe(
				data => {
					this.language = data.language
					this.expertises = data.exspec
					this.licenses = data.license
					this.activities = [{id:0, name:'Other'}]
					this.activities = this.activities.concat(data.service)
				},
				error => {
					return false
				}
			)
		}
	}
	prevstep(){
		this.errFlag = 0
		this.step--
	}
	goToGeo(){
		this.geoError = false
		this.userdata.latitude= 0
		this.userdata.longitude=0
		this.step = 1
	}
	openTimeSetting(event, data){
		$('.time-setting').fadeOut()
		if(data.checked)
			$(event).parents('.form-group').find('.time-setting').fadeIn()
	}
	goNextForm(step){
		this.step = step
	}
	getAddress(place: object) { 
		this.userdata.latitude = place['geometry']['location'].lat()
		this.userdata.longitude = place['geometry']['location'].lng()
		this.userdata.address = place['formatted_address']
	}
	changeActivity(target){
		if(this.userdata.activities[this.userdata.activities.length-1]==0){
			this.userdata.activities = [0]
			this.userdata.otherActivityFlag = true
			target.close()
		} else {
			this.userdata.otherActivityFlag = false
			if(this.userdata.activities[0]==0){
				let acti = this.userdata.activities
				this.userdata.activities=[]
				for(let i of acti){
					if(i==0)
						continue
					this.userdata.activities.push(i)
				}
			}
		}
	}
}
