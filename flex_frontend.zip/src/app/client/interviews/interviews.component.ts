import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { RejectComponent} from "../../caregiver/reject/reject.component";
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';
declare var $: any;

@Component({
	selector: 'app-interviews',
	templateUrl: './interviews.component.html',
	styleUrls: ['./interviews.component.scss']
})
export class InterviewsclientComponent implements OnInit {
	interviews = []
	weekName = []
	filePath=''
	constructor(
		private _bottomSheet:MatDialog,
		private apiservice: ApiService,
		private router: Router,
	) {
		this.filePath = apiservice.env.downUrl
	}

	ngOnInit(): void {
		this.weekName = this.apiservice.weekName
		this.apiservice.getClientInterviews().subscribe(
			data=>{
				if(data.status=='success'){
					this.interviews = data.interviewlist
					for(let i=0; i<this.interviews.length;i++){
						if(this.interviews[i].licensename)
							this.interviews[i].licensename = this.interviews[i].licensename.split("<||>")
						if(this.interviews[i].licenseimg)
							this.interviews[i].licenseimg = this.interviews[i].licenseimg.split("<||>")
					}
				}
			},
			error => {

			}
		)
	}
	cancelInterview(id, target){
		const dialogConfig = new MatDialogConfig();
		dialogConfig.data = {target:'interview', jobId:id}
		const bottomSheetRef = this._bottomSheet.open(RejectComponent, dialogConfig);
		bottomSheetRef.afterClosed().subscribe(data => {
			if(data)
				$(target).addClass('rejected')
		});
	}
	go2interview(intid){
		this.apiservice.goInterview(intid).subscribe(
			data=>{
				if(data.status=='success'){
					let routerLink=`/interview-rooms/${intid}` 
					this.router.navigate([routerLink]);
				} else {

				}
			},
			error=>{
				console.log(error)
			}
		)
	}
}
