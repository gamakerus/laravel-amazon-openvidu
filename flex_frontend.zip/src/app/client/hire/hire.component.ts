import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { MatDialogRef } from  '@angular/material/dialog';
import { FlexdlgComponent } from '../../layout/flexdlg/flexdlg.component'
import { Router } from '@angular/router';
declare var $: any;
@Component({
	selector: 'app-hire',
	templateUrl: './hire.component.html',
	styleUrls: ['./hire.component.scss']
})
export class HireComponent implements OnInit {
	step = 1
	services = []
	expertises = []
	licenses = []
	selected = {
		services : [],
		expertises : [],
		licenses : [],
		service_time:null,
		selectedDay:null,
		selectedHour:{
			live_in:false,
			start:0,
			end:0
		},
		startdate:null,
		enddate:null,
		scheduleType:"1",
		schedule:null,
		everyday:1,
		exclude:false,
		daysSelected:[], 
		userId:null,
		totalHours:0,
		pricePerHour:0,
		totalPrice:0
	}
	errFlag = 0
	service_time = []
	daysperweek = []
	hoursperday = []
	weekName = []
	encapsulation:ViewEncapsulation.None
	jobId = null
	loading = false
	@Input() userId:any
	constructor(
		private apiservice: ApiService,
		private dialogRef:MatDialogRef<FlexdlgComponent>,
		private router: Router,
	) { }

	ngOnInit(): void {
		this.weekName = this.apiservice.weekName
		this.apiservice.getUserMisInfo(this.userId).subscribe(
			data => {
				this.services = data.service
				this.expertises = data.exspec
				this.licenses = data.license
				this.service_time = data.stime
				this.daysperweek = data.daytoweek
				this.hoursperday = data.timetoday
			},
			error=>{
				console.log(error)
			}
		)
	}
	prevstep(){
		this.errFlag = 0
		this.step--
	}
	nextstep(){
		this.errFlag = 0
		if(this.step==2){
			if(this.selected.startdate==null){
				this.errFlag = 2
				return false
			}
			this.step++
		} else {
			console.log(this.selected)
			this.step++
		}
	}
	setCost(){
		this.errFlag = 0
		if(!this.selected.startdate){
			this.errFlag = 1
			return false
		}
		if(this.selected.selectedHour.start==0 && this.selected.selectedHour.end==0 && this.selected.selectedHour.live_in==false){
			this.errFlag = 2
			return false
		}
		this.selected.userId = this.userId;
		this.apiservice.setCost(this.selected).subscribe(
			data=>{
				if(data.status=='success' && data.price>0){
					this.selected.totalHours = data.hour
					this.selected.pricePerHour = data.priceperhour
					this.selected.totalPrice = data.price
					this.step++
				}else{
					this.errFlag = 3
				}
			},
			error=>{
				this.errFlag = 3
			}
		)
	}
	openTimeSetting(event){
		$('.time-setting').fadeOut()
		if(this.selected.everyday)
			$(event).fadeIn()
	}
	closeTimePanel(data:any){
		$('.time-setting').fadeOut()
	}
	isSelected = (event: any) => {
		const date =
			event.getFullYear() +
			"-" +
			("00" + (event.getMonth() + 1)).slice(-2) +
			"-" +
			("00" + event.getDate()).slice(-2);
		return this.selected.daysSelected.find(x => x == date) ? "selected" : null;
	};
	
	select(event: any, calendar: any) {
		const date =
			event.getFullYear() +
			"-" +
			("00" + (event.getMonth() + 1)).slice(-2) +
			"-" +
			("00" + event.getDate()).slice(-2);
		const index = this.selected.daysSelected.findIndex(x => x == date);
		if (index < 0) this.selected.daysSelected.push(date);
		else this.selected.daysSelected.splice(index, 1);
	
		calendar.updateTodaysDate();
	}

	openCalendar(){
		if(this.selected.everyday==0){
			this.selected.exclude = true
			$(".ex-calendar").fadeIn()
		}else{
			this.selected.exclude = false
			$(".ex-calendar").fadeOut()
		}
	}
	closeCalendar(){
		$(".ex-calendar").fadeOut()
	}
	payNow(){
		this.loading = true
		this.errFlag = 0
		let search = JSON.parse(localStorage.getItem('searchFilter'))
		this.apiservice.requestJob(this.selected, search).subscribe(
			data=>{
				this.loading = false
				if(data.status=='success'){
					this.step = 10
					this.jobId = data.jobid
				} else {
					this.errFlag = 3
				}
			},
			error=>{
				this.loading = false
				this.errFlag = 3
			}
		)
		
	}
	doAfterPay($event){
		if($event){
			this.dialogRef.close();
			this.router.navigate(['/client/incoming']);
		}
	}
}
