import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from '../services/api.service';

@Component({
  selector: 'app-resetpassword',
  templateUrl: './resetpassword.component.html',
  styleUrls: ['./resetpassword.component.scss']
})
export class ResetpasswordComponent implements OnInit {
  status = false
  constructor(
    private route: ActivatedRoute,
    private apiservice: ApiService,
  ) { }

  ngOnInit(): void {
    const token = this.route.snapshot.paramMap.get('token');
    this.apiservice.hideHeader()
    this.apiservice.verifyToken(token).subscribe(
      data => {
        if(data.status=='success'){
          localStorage.setItem('user_token', token);
          this.status = true
        } else {
          this.status = false
        }
      },
      error => {
        this.status = false
        console.log(error)
      }
    )
  }

}
