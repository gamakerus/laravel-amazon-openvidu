import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component'
import { AuthGuard } from './helpers/auth.guard';
import { ProfileComponent} from './caregiver/profile/profile.component'
import { DashboardComponent} from './dashboard/dashboard.component'
import { EditprofileComponent} from './caregiver/editprofile/editprofile.component'
import { EditprofileclientComponent} from './client/editprofile/editprofile.component'
import { IncomingComponent} from './caregiver/incoming/incoming.component'
import { IncomingclientComponent} from './client/incoming/incoming.component'
import { OngoingComponent} from './caregiver/ongoing/ongoing.component'
import { OngoingclientComponent} from './client/ongoing/ongoing.component'
import { PastComponent} from './caregiver/past/past.component'
import { InterviewsComponent} from './caregiver/interviews/interviews.component'
import { InterviewsclientComponent} from './client/interviews/interviews.component'
import { RefundsComponent} from './client/refunds/refunds.component'
import { SchedulesComponent} from './caregiver/schedules/schedules.component'
import { ServicesComponent} from './caregiver/services/services.component'
import { TransactionsComponent} from './caregiver/transactions/transactions.component'
import { TransactionsclientComponent} from './client/transactions/transactions.component'
import { SearchresultComponent} from './client/searchresult/searchresult.component'
import { FinishedComponent} from './client/finished/finished.component'
import { ResetpasswordComponent} from './resetpassword/resetpassword.component'
import { VideocallComponent} from './layout/videocall/videocall.component'
import { NotificationComponent} from './notification/notification.component'
import { ForbiddenComponent} from './forbidden/forbidden.component'
import { LogoutComponent} from './logout/logout.component'
import { PaymentComponent} from './payment/payment.component'
const routes: Routes = [
	{	path:'',										component: HomeComponent	},
	{	path:'provider/profile',		component: ProfileComponent,		canActivate: [AuthGuard]},
	{ path:'profile/:name',						component: DashboardComponent,	canActivate: [AuthGuard]	},
	{ path:'provider/edit/:name',	component: EditprofileComponent, canActivate: [AuthGuard]},
	{ path:'client/edit/:name',	component: EditprofileclientComponent, canActivate: [AuthGuard]},
	{ path:'provider/incoming',	component: IncomingComponent, canActivate: [AuthGuard]},
	{ path:'provider/ongoing',		component: OngoingComponent, canActivate: [AuthGuard]},
	{ path:'provider/previous',	component: PastComponent, canActivate: [AuthGuard]},
	{ path:'provider/previous/:page',	component: PastComponent, canActivate: [AuthGuard]},
	{ path:'provider/interviews',component: InterviewsComponent, canActivate: [AuthGuard]},
	{ path:'provider/schedules',component: SchedulesComponent, canActivate: [AuthGuard]},
	{ path:'provider/services',	component: ServicesComponent, canActivate: [AuthGuard]},
	{ path:'provider/transactions',	component: TransactionsComponent, canActivate: [AuthGuard]},
	{ path:'provider/transactions/:page',	component: TransactionsComponent, canActivate: [AuthGuard]},
	{ path:'search/caregivers/:page',	component: SearchresultComponent, canActivate: [AuthGuard]},
	{ path:'search/caregivers',	component: SearchresultComponent, canActivate: [AuthGuard]},
	{ path:'password_reset/:token',	component: ResetpasswordComponent, canActivate: [AuthGuard]},
	{ path:'client/incoming',	component: IncomingclientComponent, canActivate: [AuthGuard]},
	{ path:'client/ongoing',	component: OngoingclientComponent, canActivate: [AuthGuard]},
	{ path:'client/interviews',component: InterviewsclientComponent, canActivate: [AuthGuard]},
	{ path:'client/transactions',	component: TransactionsclientComponent, canActivate: [AuthGuard]},
	{ path:'client/transactions/:page',	component: TransactionsclientComponent, canActivate: [AuthGuard]},
	{ path:'client/previous',	component: FinishedComponent, canActivate: [AuthGuard]},
	{ path:'client/previous/:page',	component: FinishedComponent, canActivate: [AuthGuard]},
	{ path:'client/refunds',	component: RefundsComponent, canActivate: [AuthGuard]},
	{ path:'client/refunds/:page',	component: RefundsComponent, canActivate: [AuthGuard]},
	{ path:'interview-rooms/:id',	component: VideocallComponent, canActivate: [AuthGuard]},
	{ path:'notification',	component: NotificationComponent, canActivate: [AuthGuard]},
	{ path:'notification/:page',	component: NotificationComponent, canActivate: [AuthGuard]},
	{ path:'under-review',	component: ForbiddenComponent},
	{ path:'logout',	component: LogoutComponent},
	{ path:'payment',	component: PaymentComponent},
];

@NgModule({
	imports: [RouterModule.forRoot(routes)],
	exports: [RouterModule]
})
export class AppRoutingModule { }
